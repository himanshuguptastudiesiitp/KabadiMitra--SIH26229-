# Kabadiwala Connect — SIH 2026 SIH26229

Phone-style web prototype for informal scrap collectors.

Chain: COLLECT → IDENTIFY → VALUE → MATCH → HANDOVER → VERIFY → GET PAID → TRACE

Roles: Collector, Recycler (yard), Admin.

## Change colours
Edit `src/theme/app-theme.ts` only. Screens do not hardcode hex.

## Folders
- `src/theme/` — colours
- `src/lib/` — lots, pipeline, i18n, storage
- `src/screens/` — pages
- `src/components/` — shared UI
- `src/routes/` — URLs

## Languages
Hindi (default), Marathi, English — Settings.

This is a React + TypeScript web prototype, not Flutter Dart.
