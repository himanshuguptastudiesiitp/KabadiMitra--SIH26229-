import type { Lot, LotStatus, PipelineStep, UserRole } from "@/lib/types";

export type StepKey =
  | "stepCollect"
  | "stepIdentify"
  | "stepValue"
  | "stepMatch"
  | "stepHandover"
  | "stepVerify"
  | "stepPaid"
  | "stepTrace";

export const PIPELINE_STEPS: { id: PipelineStep; key: StepKey }[] = [
  { id: "collect", key: "stepCollect" },
  { id: "identify", key: "stepIdentify" },
  { id: "value", key: "stepValue" },
  { id: "match", key: "stepMatch" },
  { id: "handover", key: "stepHandover" },
  { id: "verify", key: "stepVerify" },
  { id: "paid", key: "stepPaid" },
  { id: "trace", key: "stepTrace" },
];

export function statusToStep(status: LotStatus): PipelineStep {
  switch (status) {
    case "collected":
      return "collect";
    case "identified":
      return "identify";
    case "valued":
      return "value";
    case "matched":
    case "offered":
    case "accepted":
    case "rejected":
      return "match";
    case "handed":
      return "handover";
    case "verified":
      return "verify";
    case "paid":
      return "paid";
    default:
      return "collect";
  }
}

export function stepIndex(status: LotStatus): number {
  const step = statusToStep(status);
  const i = PIPELINE_STEPS.findIndex((s) => s.id === step);
  return i < 0 ? 0 : i;
}

export function lotAmount(lot: Lot): number {
  return lot.finalPrice ?? lot.offerPrice ?? lot.quotedPrice ?? lot.estimatedValue;
}

export function pickActiveLot(lots: Lot[]): Lot | undefined {
  const open = lots.filter((l) => l.paymentStatus !== "paid" && l.status !== "rejected");
  if (open.length === 0) return lots[0];
  const rank: LotStatus[] = [
    "offered",
    "accepted",
    "handed",
    "verified",
    "matched",
    "valued",
    "identified",
    "collected",
  ];
  return [...open].sort((a, b) => rank.indexOf(a.status) - rank.indexOf(b.status))[0];
}

export function homePath(role: UserRole): "/" | "/user" | "/recycler" | "/admin" {
  if (role === "recycler") return "/recycler";
  if (role === "admin") return "/admin";
  return "/";
}

export function nextPath(lot: Lot | undefined): string {
  if (!lot) return "/camera";
  switch (lot.status) {
    case "collected":
    case "identified":
      return "/add";
    case "valued":
    case "matched":
    case "offered":
      return "/recyclers";
    case "accepted":
      return `/handover?lot=${lot.id}`;
    case "handed":
    case "verified":
      return "/earnings";
    case "paid":
      return `/trace?lot=${lot.id}`;
    default:
      return "/camera";
  }
}
