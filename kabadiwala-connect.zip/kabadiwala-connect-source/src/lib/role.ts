import type { UserRole } from "@/lib/types";
import { homePath } from "@/lib/pipeline";

export function deskLabel(role: UserRole): { hi: string; mr: string; en: string } {
  if (role === "recycler") return { hi: "यार्ड डेस्क", mr: "यार्ड डेस्क", en: "Yard desk" };
  if (role === "admin") return { hi: "एडमिन डेस्क", mr: "अॅडमीन डेस्क", en: "Admin desk" };
  return { hi: "कलेक्टर डेस्क", mr: "कलेक्टर डेस्क", en: "Collector desk" };
}

export { homePath };
