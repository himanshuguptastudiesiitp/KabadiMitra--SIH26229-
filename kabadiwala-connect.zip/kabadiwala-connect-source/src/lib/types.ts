export type Lang = "hi" | "mr" | "en";
export type MaterialId = "crt" | "lcd" | "pcb" | "cables" | "batteries" | "motors" | "plastics";
export type LotStatus =
  | "collected"
  | "identified"
  | "valued"
  | "matched"
  | "offered"
  | "accepted"
  | "rejected"
  | "handed"
  | "verified"
  | "paid";
export type PayMethod = "cash" | "upi";
export type PayStatus = "none" | "pending" | "paid";
export type UserRole = "collector" | "recycler" | "admin";
export type PickupStatus = "none" | "requested" | "scheduled" | "done";
export type PipelineStep =
  | "collect"
  | "identify"
  | "value"
  | "match"
  | "handover"
  | "verify"
  | "paid"
  | "trace";

export type GeoPoint = { lat: number; lng: number; label: string };
export type LotEvent = { step: PipelineStep; at: string; note?: string };

export type Lot = {
  id: string;
  category: MaterialId;
  weightKg: number;
  photoDataUrl?: string;
  estimatedValue: number;
  ratePerKg: number;
  quotedPrice?: number;
  offerPrice?: number;
  finalPrice?: number;
  status: LotStatus;
  createdAt: string;
  location: GeoPoint;
  recyclerId?: string;
  handoverRef?: string;
  paymentMethod: PayMethod;
  paymentStatus: PayStatus;
  synced: boolean;
  collectorName: string;
  collectorArea: string;
  pickupStatus: PickupStatus;
  receivedWeightKg?: number;
  events: LotEvent[];
};

export type Recycler = {
  id: string;
  name: string;
  city: string;
  lat: number;
  lng: number;
  materials: MaterialId[];
  rateBonus: number;
  pickup: boolean;
  authorized: boolean;
  phone: string;
  area: string;
  km: number;
};

export type PriceRow = {
  category: MaterialId;
  ratePerKg: number;
  low: number;
  high: number;
  trend: number[];
};

export type ScrapPhoto = {
  id: string;
  dataUrl: string;
  createdAt: string;
  category?: MaterialId;
};

export type CollectorNote = {
  id: string;
  name: string;
  area: string;
  lots: number;
  earned: number;
  kg: number;
};

export type Anomaly = {
  id: string;
  lotId: string;
  kind: "weight" | "stuck" | "price" | "reject";
  textKey: "anomalyWeight" | "anomalyStuck" | "anomalyPrice" | "anomalyReject";
};
