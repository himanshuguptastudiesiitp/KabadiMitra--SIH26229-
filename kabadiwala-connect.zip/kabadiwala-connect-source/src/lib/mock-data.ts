import type { Anomaly, CollectorNote, Lot, MaterialId, PriceRow, Recycler } from "@/lib/types";

export const MATERIAL_ORDER: MaterialId[] = [
  "crt",
  "lcd",
  "pcb",
  "cables",
  "batteries",
  "motors",
  "plastics",
];

export const NAGPUR = { lat: 21.1458, lng: 79.0882, label: "इतवारी, नागपुर" };

export const PRICE_BOARD: PriceRow[] = [
  { category: "pcb", ratePerKg: 280, low: 240, high: 320, trend: [250, 255, 270, 275, 280] },
  { category: "cables", ratePerKg: 95, low: 80, high: 110, trend: [88, 90, 92, 94, 95] },
  { category: "batteries", ratePerKg: 72, low: 60, high: 85, trend: [78, 76, 74, 73, 72] },
  { category: "motors", ratePerKg: 48, low: 40, high: 55, trend: [44, 45, 46, 47, 48] },
  { category: "lcd", ratePerKg: 38, low: 30, high: 45, trend: [32, 34, 35, 37, 38] },
  { category: "crt", ratePerKg: 12, low: 8, high: 16, trend: [10, 11, 11, 12, 12] },
  { category: "plastics", ratePerKg: 18, low: 12, high: 22, trend: [16, 16, 17, 18, 18] },
];

export function rateFor(category: MaterialId): PriceRow {
  return PRICE_BOARD.find((p) => p.category === category) ?? PRICE_BOARD[0];
}

export const RECYCLERS: Recycler[] = [
  {
    id: "r1",
    name: "श्री गणेश ई-वेस्ट",
    city: "नागपुर",
    lat: 21.1498,
    lng: 79.0912,
    materials: ["pcb", "cables", "lcd", "batteries"],
    rateBonus: 8,
    pickup: true,
    authorized: true,
    phone: "0712-2241188",
    area: "इतवारी",
    km: 1.4,
  },
  {
    id: "r2",
    name: "नाग ईको रिकवरी",
    city: "नागपुर",
    lat: 21.1612,
    lng: 79.0788,
    materials: ["crt", "lcd", "motors", "plastics"],
    rateBonus: 4,
    pickup: true,
    authorized: true,
    phone: "0712-2550091",
    area: "सीताबर्डी",
    km: 3.2,
  },
  {
    id: "r3",
    name: "मेट्रो स्क्रैप यार्ड",
    city: "नागपुर",
    lat: 21.129,
    lng: 79.11,
    materials: ["motors", "cables", "plastics", "pcb"],
    rateBonus: 0,
    pickup: false,
    authorized: true,
    phone: "0712-2704410",
    area: "कपूरधारा",
    km: 4.8,
  },
  {
    id: "r4",
    name: "बजरंग कबाड़",
    city: "नागपुर",
    lat: 21.118,
    lng: 79.07,
    materials: ["crt", "plastics"],
    rateBonus: -6,
    pickup: false,
    authorized: false,
    phone: "98230-44112",
    area: "धरमपेठ",
    km: 6.1,
  },
];

function ev(step: Lot["events"][number]["step"], hoursAgo: number, note?: string) {
  return {
    step,
    at: new Date(Date.now() - hoursAgo * 3600_000).toISOString(),
    note,
  };
}

export const SAMPLE_LOTS: Lot[] = [
  {
    id: "L-1042",
    category: "pcb",
    weightKg: 4.5,
    estimatedValue: 1260,
    ratePerKg: 280,
    quotedPrice: 1296,
    offerPrice: 1320,
    status: "offered",
    createdAt: new Date(Date.now() - 3 * 3600_000).toISOString(),
    location: NAGPUR,
    recyclerId: "r1",
    paymentMethod: "cash",
    paymentStatus: "pending",
    synced: false,
    collectorName: "रामू काका",
    collectorArea: "इतवारी",
    pickupStatus: "none",
    events: [
      ev("collect", 3),
      ev("identify", 2.8, "PCB"),
      ev("value", 2.7),
      ev("match", 2.4, "श्री गणेश"),
    ],
  },
  {
    id: "L-1038",
    category: "cables",
    weightKg: 12,
    estimatedValue: 1140,
    ratePerKg: 95,
    quotedPrice: 1140,
    offerPrice: 1180,
    finalPrice: 1180,
    status: "accepted",
    createdAt: new Date(Date.now() - 8 * 3600_000).toISOString(),
    location: { lat: 21.15, lng: 79.09, label: "महाकाली, नागपुर" },
    recyclerId: "r1",
    paymentMethod: "cash",
    paymentStatus: "pending",
    synced: true,
    collectorName: "रामू काका",
    collectorArea: "इतवारी",
    pickupStatus: "scheduled",
    events: [
      ev("collect", 8),
      ev("identify", 7.8),
      ev("value", 7.6),
      ev("match", 7.2),
    ],
  },
  {
    id: "L-1021",
    category: "batteries",
    weightKg: 8,
    estimatedValue: 576,
    ratePerKg: 72,
    quotedPrice: 576,
    offerPrice: 560,
    finalPrice: 540,
    receivedWeightKg: 7.5,
    status: "paid",
    createdAt: new Date(Date.now() - 30 * 3600_000).toISOString(),
    location: NAGPUR,
    recyclerId: "r1",
    handoverRef: "KC-77821",
    paymentMethod: "cash",
    paymentStatus: "paid",
    synced: true,
    collectorName: "रामू काका",
    collectorArea: "इतवारी",
    pickupStatus: "done",
    events: [
      ev("collect", 30),
      ev("identify", 29.5),
      ev("value", 29),
      ev("match", 28),
      ev("handover", 26, "KC-77821"),
      ev("verify", 25, "7.5 kg"),
      ev("paid", 24, "नकद 540"),
      ev("trace", 24),
    ],
  },
  {
    id: "L-1014",
    category: "crt",
    weightKg: 18,
    estimatedValue: 216,
    ratePerKg: 12,
    quotedPrice: 216,
    status: "valued",
    createdAt: new Date(Date.now() - 5 * 3600_000).toISOString(),
    location: NAGPUR,
    paymentMethod: "cash",
    paymentStatus: "none",
    synced: false,
    collectorName: "रामू काका",
    collectorArea: "इतवारी",
    pickupStatus: "none",
    events: [ev("collect", 5), ev("identify", 4.8), ev("value", 4.7)],
  },
];

export const COLLECTOR_NOTES: CollectorNote[] = [
  { id: "c1", name: "रामू काका", area: "इतवारी", lots: 18, earned: 12440, kg: 96 },
  { id: "c2", name: "सलीम भाई", area: "महाकाली", lots: 11, earned: 8020, kg: 64 },
  { id: "c3", name: "मीना बाई", area: "धरमपेठ", lots: 9, earned: 5110, kg: 41 },
];

export const ANOMALIES: Anomaly[] = [
  { id: "a1", lotId: "L-1042", kind: "stuck", textKey: "anomalyStuck" },
  { id: "a2", lotId: "L-1021", kind: "weight", textKey: "anomalyWeight" },
];

export const DEMO_PHOTOS = [
  "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='640' height='480'><rect fill='%23333' width='640' height='480'/><rect fill='%23666' x='80' y='70' width='480' height='340'/><text x='320' y='250' text-anchor='middle' fill='white' font-size='36' font-family='sans-serif'>PCB BOARD</text></svg>",
  "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='640' height='480'><rect fill='%23222' width='640' height='480'/><circle fill='%23c45c26' cx='320' cy='240' r='140'/><text x='320' y='250' text-anchor='middle' fill='white' font-size='32' font-family='sans-serif'>BATTERY</text></svg>",
  "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='640' height='480'><rect fill='%231a1714' width='640' height='480'/><rect fill='%23888' x='140' y='90' width='360' height='280'/><text x='320' y='250' text-anchor='middle' fill='white' font-size='32' font-family='sans-serif'>CABLES</text></svg>",
];
