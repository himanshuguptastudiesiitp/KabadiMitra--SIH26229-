export function inr(n: number): string {
  return `₹${Math.round(n).toLocaleString("en-IN")}`;
}

export function shortDate(iso: string, lang: string): string {
  const d = new Date(iso);
  return d.toLocaleString(lang === "en" ? "en-IN" : "hi-IN", {
    day: "numeric",
    month: "short",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function kmLabel(km: number): string {
  return km < 10 ? km.toFixed(1) : String(Math.round(km));
}
