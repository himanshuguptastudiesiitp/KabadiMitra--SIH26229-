import type { MaterialId } from "@/lib/types";
import { MATERIAL_ORDER } from "@/lib/mock-data";

export type ClassifyResult = { category: MaterialId; confidence: number };
export interface MaterialClassifier {
  classify(imageDataUrl: string): Promise<ClassifyResult>;
}

function hashString(s: string): number {
  let h = 0;
  const slice = s.slice(0, 800);
  for (let i = 0; i < slice.length; i++) h = (h * 31 + slice.charCodeAt(i)) | 0;
  return Math.abs(h);
}

export class MockMaterialClassifier implements MaterialClassifier {
  async classify(imageDataUrl: string): Promise<ClassifyResult> {
    await new Promise((r) => setTimeout(r, 650));
    const i = hashString(imageDataUrl) % MATERIAL_ORDER.length;
    return { category: MATERIAL_ORDER[i], confidence: 0.72 + (i % 3) * 0.07 };
  }
}

let active: MaterialClassifier = new MockMaterialClassifier();
export function getClassifier(): MaterialClassifier {
  return active;
}
export function setClassifier(next: MaterialClassifier): void {
  active = next;
}
