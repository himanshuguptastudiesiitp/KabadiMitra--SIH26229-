import { create } from "zustand";
import { persist } from "zustand/middleware";
import { SAMPLE_LOTS } from "@/lib/mock-data";
import { rateFor } from "@/lib/mock-data";
import type { Lang, Lot, LotStatus, PayMethod, PickupStatus, ScrapPhoto, UserRole } from "@/lib/types";
import type { ThemeId } from "@/theme/app-theme";
import { DEFAULT_THEME_ID } from "@/theme/app-theme";

type ProfilePatch = {
  displayName?: string;
  onboardingDone?: boolean;
  role?: UserRole;
};

type AppState = {
  language: Lang;
  themeId: ThemeId;
  role: UserRole;
  displayName: string;
  onboardingDone: boolean;
  voiceOn: boolean;
  lots: Lot[];
  photos: ScrapPhoto[];
  pendingPhoto?: string;
  setLanguage: (language: Lang) => void;
  setThemeId: (themeId: ThemeId) => void;
  setRole: (role: UserRole) => void;
  setVoiceOn: (voiceOn: boolean) => void;
  applyProfile: (patch: ProfilePatch) => void;
  setPendingPhoto: (dataUrl?: string) => void;
  addPhoto: (dataUrl: string) => ScrapPhoto;
  addLot: (lot: Omit<Lot, "id" | "createdAt" | "events" | "synced">) => Lot;
  updateLot: (id: string, patch: Partial<Lot>) => void;
  markSynced: () => void;
  offerLot: (id: string, recyclerId: string, offerPrice: number) => void;
  acceptOffer: (id: string) => void;
  rejectOffer: (id: string) => void;
  setPickup: (id: string, pickupStatus: PickupStatus) => void;
  handoverLot: (id: string, method: PayMethod) => string;
  verifyLot: (id: string, receivedWeightKg: number) => void;
  payLot: (id: string, method: PayMethod, amount: number) => void;
};

function uid(prefix: string): string {
  return `${prefix}-${Math.random().toString(36).slice(2, 8)}`;
}

function nowIso(): string {
  return new Date().toISOString();
}

function pushEvent(lot: Lot, step: Lot["events"][number]["step"], note?: string): Lot {
  return { ...lot, events: [...lot.events, { step, at: nowIso(), note }] };
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      language: "hi",
      themeId: DEFAULT_THEME_ID,
      role: "collector",
      displayName: "",
      onboardingDone: false,
      voiceOn: true,
      lots: SAMPLE_LOTS,
      photos: [],
      pendingPhoto: undefined,
      setLanguage: (language) => set({ language }),
      setThemeId: (themeId) => set({ themeId }),
      setRole: (role) => set({ role }),
      setVoiceOn: (voiceOn) => set({ voiceOn }),
      applyProfile: (patch) => set(patch),
      setPendingPhoto: (pendingPhoto) => set({ pendingPhoto }),
      addPhoto: (dataUrl) => {
        const photo: ScrapPhoto = { id: uid("P"), dataUrl, createdAt: nowIso() };
        set({ photos: [photo, ...get().photos], pendingPhoto: dataUrl });
        return photo;
      },
      addLot: (input) => {
        const lot: Lot = {
          ...input,
          id: uid("L"),
          createdAt: nowIso(),
          synced: false,
          events: [
            { step: "collect", at: nowIso() },
            { step: "identify", at: nowIso(), note: input.category },
            { step: "value", at: nowIso() },
          ],
        };
        set({ lots: [lot, ...get().lots], pendingPhoto: undefined });
        return lot;
      },
      updateLot: (id, patch) =>
        set({ lots: get().lots.map((l) => (l.id === id ? { ...l, ...patch } : l)) }),
      markSynced: () => set({ lots: get().lots.map((l) => ({ ...l, synced: true })) }),
      offerLot: (id, recyclerId, offerPrice) =>
        set({
          lots: get().lots.map((l) =>
            l.id === id
              ? pushEvent(
                  {
                    ...l,
                    recyclerId,
                    offerPrice,
                    quotedPrice: offerPrice,
                    status: "offered",
                    paymentStatus: "pending",
                    synced: false,
                  },
                  "match",
                )
              : l,
          ),
        }),
      acceptOffer: (id) =>
        set({
          lots: get().lots.map((l) =>
            l.id === id ? { ...l, status: "accepted" as LotStatus, synced: false } : l,
          ),
        }),
      rejectOffer: (id) =>
        set({
          lots: get().lots.map((l) =>
            l.id === id ? { ...l, status: "rejected" as LotStatus, synced: false } : l,
          ),
        }),
      setPickup: (id, pickupStatus) =>
        set({
          lots: get().lots.map((l) => (l.id === id ? { ...l, pickupStatus, synced: false } : l)),
        }),
      handoverLot: (id, method) => {
        const ref = `KC-${Math.floor(10000 + Math.random() * 89999)}`;
        set({
          lots: get().lots.map((l) =>
            l.id === id
              ? pushEvent(
                  {
                    ...l,
                    handoverRef: ref,
                    paymentMethod: method,
                    status: "handed",
                    synced: false,
                  },
                  "handover",
                  ref,
                )
              : l,
          ),
        });
        return ref;
      },
      verifyLot: (id, receivedWeightKg) => {
        const row = rateFor(get().lots.find((l) => l.id === id)?.category ?? "pcb");
        const amount = Math.round(receivedWeightKg * row.ratePerKg);
        set({
          lots: get().lots.map((l) =>
            l.id === id
              ? pushEvent(
                  {
                    ...l,
                    receivedWeightKg,
                    finalPrice: amount,
                    status: "verified",
                    synced: false,
                  },
                  "verify",
                  `${receivedWeightKg} kg`,
                )
              : l,
          ),
        });
      },
      payLot: (id, method, amount) =>
        set({
          lots: get().lots.map((l) =>
            l.id === id
              ? pushEvent(
                  {
                    ...l,
                    paymentMethod: method,
                    paymentStatus: "paid",
                    finalPrice: amount,
                    status: "paid",
                    pickupStatus: "done",
                    synced: false,
                  },
                  "paid",
                  `${method} ${amount}`,
                )
              : l,
          ),
        }),
    }),
    {
      name: "kc-store-v4",
      version: 4,
    },
  ),
);
