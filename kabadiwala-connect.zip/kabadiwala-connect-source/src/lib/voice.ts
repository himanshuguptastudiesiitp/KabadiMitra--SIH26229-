import type { Lang } from "@/lib/types";

const LANG_TAG: Record<Lang, string> = { hi: "hi-IN", mr: "mr-IN", en: "en-IN" };

export function speak(text: string, lang: Lang): void {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.lang = LANG_TAG[lang];
  u.rate = 0.92;
  const voices = window.speechSynthesis.getVoices();
  const match =
    voices.find((v) => v.lang === LANG_TAG[lang]) ||
    voices.find((v) => v.lang.startsWith(lang)) ||
    voices.find((v) => v.lang.startsWith("hi"));
  if (match) u.voice = match;
  window.speechSynthesis.speak(u);
}

export function stopSpeak(): void {
  if (typeof window === "undefined" || !("speechSynthesis" in window)) return;
  window.speechSynthesis.cancel();
}
