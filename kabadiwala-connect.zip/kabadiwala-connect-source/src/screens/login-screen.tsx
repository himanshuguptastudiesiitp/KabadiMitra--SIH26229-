import { Link, Navigate, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { PhoneChrome, PhoneSkeleton } from "@/components/phone-chrome";
import { BigButton, TextField } from "@/components/ui-bits";
import { GROK_PROVIDERS, authClient, authEnabled, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { t } from "@/lib/i18n";
import { homePath } from "@/lib/pipeline";
import { useAppStore } from "@/lib/store";

export function LoginScreen() {
  const language = useAppStore((s) => s.language);
  const onboarded = useAppStore((s) => s.onboardingDone);
  const role = useAppStore((s) => s.role);
  const applyProfile = useAppStore((s) => s.applyProfile);
  const displayName = useAppStore((s) => s.displayName);
  const { user, isPending } = useCurrentUserState();
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  if (isPending) return <PhoneSkeleton />;
  if (user) return <Navigate to={onboarded ? homePath(role) : "/onboarding"} />;

  async function onLogin() {
    setError("");
    if (!email.includes("@")) {
      setError(t(language, "needEmail"));
      return;
    }
    if (password.length < 8) {
      setError(t(language, "needPassword"));
      return;
    }
    setBusy(true);
    const { error: err } = await authClient.signIn.email({ email: email.trim(), password });
    setBusy(false);
    if (err) {
      setError(t(language, "badLogin"));
      return;
    }
    void navigate({ to: onboarded ? homePath(role) : "/onboarding" });
  }

  function skipAccount() {
    applyProfile({ displayName: displayName || t(language, "sampleName"), onboardingDone: true });
    void navigate({ to: homePath(role) });
  }

  return (
    <PhoneChrome>
      <div className="flex flex-col gap-4">
        <h1 className="text-3xl font-extrabold text-ink">{t(language, "login")}</h1>
        <p className="text-muted">{t(language, "loginSub")}</p>
        <TextField label={t(language, "email")} type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        <TextField
          label={t(language, "password")}
          type="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        {error ? <p className="font-bold text-danger">{error}</p> : null}
        <BigButton disabled={busy} onClick={() => void onLogin()}>
          {busy ? t(language, "working") : t(language, "loginGo")}
        </BigButton>
        {authEnabled
          ? GROK_PROVIDERS.map((p) => (
              <BigButton
                key={p.providerId}
                tone="ghost"
                onClick={() => void signIn(p.providerId, { callbackURL: "/onboarding" })}
              >
                {p.providerId.includes("google") ? t(language, "googleGo") : t(language, "xGo")}
              </BigButton>
            ))
          : null}
        <Link to="/register" className="flex min-h-14 items-center justify-center rounded-xl bg-surface font-bold text-ink">
          {t(language, "newAccount")}
        </Link>
        <button type="button" onClick={skipAccount} className="min-h-12 font-bold text-primary">
          {t(language, "skipLogin")}
        </button>
      </div>
    </PhoneChrome>
  );
}
