import { Link } from "@tanstack/react-router";
import { Palette } from "lucide-react";
import { Card, ScreenTitle } from "@/components/ui-bits";
import { t } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";
import { getTheme } from "@/theme/app-theme";
import type { Lang } from "@/lib/types";

const LANGS: { id: Lang; label: string }[] = [
  { id: "hi", label: "हिंदी" },
  { id: "mr", label: "मराठी" },
  { id: "en", label: "English" },
];

export function SettingsScreen() {
  const language = useAppStore((s) => s.language);
  const setLanguage = useAppStore((s) => s.setLanguage);
  const voiceOn = useAppStore((s) => s.voiceOn);
  const setVoiceOn = useAppStore((s) => s.setVoiceOn);
  const themeId = useAppStore((s) => s.themeId);
  const theme = getTheme(themeId);
  const markSynced = useAppStore((s) => s.markSynced);
  const lots = useAppStore((s) => s.lots);
  const pending = lots.filter((l) => !l.synced).length;

  return (
    <div className="flex flex-col gap-4">
      <ScreenTitle title={t(language, "settings")} sub={t(language, "settingsSub")} />
      <Card>
        <p className="mb-2 font-extrabold">{t(language, "language")}</p>
        <div className="grid grid-cols-3 gap-2">
          {LANGS.map((l) => (
            <button
              key={l.id}
              type="button"
              onClick={() => setLanguage(l.id)}
              className={`min-h-12 rounded-xl font-bold ${language === l.id ? "bg-primary text-on-primary" : "bg-surface-alt"}`}
            >
              {l.label}
            </button>
          ))}
        </div>
      </Card>
      <Link to="/theme">
        <Card className="flex items-center gap-3">
          <Palette className="size-6 text-primary" />
          <div className="flex-1">
            <p className="font-extrabold">{t(language, "themeTitle")}</p>
            <p className="text-sm text-muted">{theme.name[language]}</p>
          </div>
        </Card>
      </Link>
      <Card className="flex items-center justify-between">
        <p className="font-extrabold">{t(language, "voice")}</p>
        <button
          type="button"
          onClick={() => setVoiceOn(!voiceOn)}
          className={`min-h-12 min-w-20 rounded-xl font-bold ${voiceOn ? "bg-primary text-on-primary" : "bg-surface-alt"}`}
        >
          {voiceOn ? t(language, "on") : t(language, "off")}
        </button>
      </Card>
      <Card>
        <p className="font-extrabold">{t(language, "offline")}</p>
        <p className="text-sm text-muted">{pending} {t(language, "notSynced")}</p>
        <button type="button" onClick={markSynced} className="mt-2 min-h-12 w-full rounded-xl bg-surface-alt font-bold">
          {t(language, "syncNow")}
        </button>
      </Card>
      <a href="/kabadiwala-connect.zip" download className="flex min-h-14 items-center justify-center rounded-xl bg-btn-secondary font-extrabold text-btn-secondary-fg">
        {t(language, "downloadZip")}
      </a>
      <a href="/ALL-CODE.txt" download className="flex min-h-14 items-center justify-center rounded-xl bg-surface font-bold">
        {t(language, "downloadText")}
      </a>
    </div>
  );
}
