import { Link, Navigate, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { PhoneChrome, PhoneSkeleton } from "@/components/phone-chrome";
import { BigButton, TextField } from "@/components/ui-bits";
import { authClient } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { t } from "@/lib/i18n";
import { homePath } from "@/lib/pipeline";
import { useAppStore } from "@/lib/store";
import type { UserRole } from "@/lib/types";

export function RegisterScreen() {
  const language = useAppStore((s) => s.language);
  const role = useAppStore((s) => s.role);
  const setRole = useAppStore((s) => s.setRole);
  const applyProfile = useAppStore((s) => s.applyProfile);
  const { user, isPending } = useCurrentUserState();
  const navigate = useNavigate();
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  if (isPending) return <PhoneSkeleton />;
  if (user) return <Navigate to="/onboarding" />;

  async function onRegister() {
    setError("");
    if (name.trim().length < 2) { setError(t(language, "needName")); return; }
    if (!email.includes("@")) { setError(t(language, "needEmail")); return; }
    if (password.length < 8) { setError(t(language, "needPassword")); return; }
    setBusy(true);
    const { error: err } = await authClient.signUp.email({
      email: email.trim(),
      password,
      name: name.trim(),
    });
    setBusy(false);
    if (err) { setError(t(language, "badRegister")); return; }
    applyProfile({ displayName: name.trim(), role, onboardingDone: false });
    void navigate({ to: "/onboarding" });
  }

  function skip() {
    applyProfile({
      displayName: name.trim() || t(language, "sampleName"),
      role,
      onboardingDone: true,
    });
    void navigate({ to: homePath(role) });
  }

  return (
    <PhoneChrome>
      <div className="flex flex-col gap-4">
        <h1 className="text-3xl font-extrabold text-ink">{t(language, "register")}</h1>
        <p className="text-muted">{t(language, "registerSub")}</p>
        <TextField label={t(language, "yourName")} value={name} onChange={(e) => setName(e.target.value)} />
        <TextField label={t(language, "email")} type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        <TextField label={t(language, "password")} type="password" value={password} onChange={(e) => setPassword(e.target.value)} />
        <p className="font-extrabold">{t(language, "pickRole")}</p>
        <div className="grid grid-cols-3 gap-2">
          {(["collector", "recycler", "admin"] as UserRole[]).map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => setRole(r)}
              className={`min-h-14 rounded-xl text-xs font-extrabold ${role === r ? "bg-primary text-on-primary" : "bg-surface"}`}
            >
              {r === "collector" ? t(language, "roleCollector") : r === "recycler" ? t(language, "roleRecycler") : t(language, "roleAdmin")}
            </button>
          ))}
        </div>
        {error ? <p className="font-bold text-danger">{error}</p> : null}
        <BigButton disabled={busy} onClick={() => void onRegister()}>
          {busy ? t(language, "working") : t(language, "registerGo")}
        </BigButton>
        <Link to="/login" className="flex min-h-14 items-center justify-center rounded-xl bg-surface font-bold">
          {t(language, "haveAccount")}
        </Link>
        <button type="button" onClick={skip} className="min-h-12 font-bold text-primary">
          {t(language, "skipLogin")}
        </button>
      </div>
    </PhoneChrome>
  );
}
