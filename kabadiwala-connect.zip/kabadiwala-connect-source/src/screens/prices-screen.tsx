import { Volume2 } from "lucide-react";
import { MATERIAL_ICON } from "@/components/icons";
import { Card, ScreenTitle } from "@/components/ui-bits";
import { inr } from "@/lib/format";
import { materialLabel, t } from "@/lib/i18n";
import { PRICE_BOARD } from "@/lib/mock-data";
import { useAppStore } from "@/lib/store";
import { speak } from "@/lib/voice";

export function PricesScreen() {
  const language = useAppStore((s) => s.language);
  const voiceOn = useAppStore((s) => s.voiceOn);

  function speakAll() {
    speak(
      PRICE_BOARD.map((p) => `${materialLabel(language, p.category)} ${p.ratePerKg} ${t(language, "rupees")}`).join(". "),
      language,
    );
  }

  return (
    <div className="flex flex-col gap-4">
      <ScreenTitle title={t(language, "priceBoard")} sub={t(language, "sampleArea")} />
      {voiceOn ? (
        <button
          type="button"
          onClick={speakAll}
          className="flex min-h-12 items-center justify-center gap-2 rounded-xl bg-surface font-bold text-ink"
        >
          <Volume2 className="size-5" />
          {t(language, "speakPrice")}
        </button>
      ) : null}
      <ul className="flex flex-col gap-2">
        {PRICE_BOARD.map((row) => {
          const Icon = MATERIAL_ICON[row.category];
          const up = row.trend[row.trend.length - 1] >= row.trend[0];
          return (
            <li key={row.category}>
              <Card className="flex items-center gap-3 p-3">
                <div className="flex size-12 items-center justify-center rounded-lg bg-surface-alt text-primary">
                  <Icon className="size-6" />
                </div>
                <div className="min-w-0 flex-1">
                  <p className="font-extrabold text-ink">{materialLabel(language, row.category)}</p>
                  <p className="text-sm text-muted">
                    {inr(row.low)}–{inr(row.high)} · {t(language, "perKg")}
                  </p>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-extrabold tabular-nums text-ink">{inr(row.ratePerKg)}</p>
                  <p className={`text-sm font-bold ${up ? "text-success" : "text-danger"}`}>
                    {up ? "▲" : "▼"} {t(language, "compared")}
                  </p>
                </div>
              </Card>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
