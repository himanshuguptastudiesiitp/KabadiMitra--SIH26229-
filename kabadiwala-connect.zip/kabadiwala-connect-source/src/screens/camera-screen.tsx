import { useRef, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Camera, ImagePlus } from "lucide-react";
import { BigButton, ScreenTitle } from "@/components/ui-bits";
import { t } from "@/lib/i18n";
import { shrinkImage } from "@/lib/image";
import { DEMO_PHOTOS } from "@/lib/mock-data";
import { useAppStore } from "@/lib/store";

export function CameraScreen() {
  const language = useAppStore((s) => s.language);
  const addPhoto = useAppStore((s) => s.addPhoto);
  const setPendingPhoto = useAppStore((s) => s.setPendingPhoto);
  const navigate = useNavigate();
  const inputRef = useRef<HTMLInputElement>(null);
  const [preview, setPreview] = useState<string>();
  const [busy, setBusy] = useState(false);

  async function onFile(file?: File) {
    if (!file) return;
    setBusy(true);
    const dataUrl = await shrinkImage(file);
    setPreview(dataUrl);
    setBusy(false);
  }

  function keep(dataUrl: string) {
    addPhoto(dataUrl);
    setPendingPhoto(dataUrl);
    void navigate({ to: "/add" });
  }

  function demo() {
    const src = DEMO_PHOTOS[Math.floor(Math.random() * DEMO_PHOTOS.length)];
    setPreview(src);
  }

  return (
    <div className="flex flex-col gap-4">
      <ScreenTitle title={t(language, "cameraTitle")} sub={t(language, "cameraSub")} />
      <div className="overflow-hidden rounded-xl bg-surface-alt">
        {preview ? (
          <img src={preview} alt="" className="h-56 w-full object-cover" />
        ) : (
          <div className="flex h-56 flex-col items-center justify-center gap-2 text-muted">
            <Camera className="size-12" />
            <p className="font-bold">{t(language, "noPhoto")}</p>
          </div>
        )}
      </div>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        capture="environment"
        className="hidden"
        onChange={(e) => void onFile(e.target.files?.[0])}
      />
      <BigButton onClick={() => inputRef.current?.click()} disabled={busy}>
        <span className="inline-flex items-center gap-2">
          <Camera className="size-5" />
          {t(language, "takePhoto")}
        </span>
      </BigButton>
      <button
        type="button"
        onClick={() => {
          const el = document.createElement("input");
          el.type = "file";
          el.accept = "image/*";
          el.onchange = () => void onFile(el.files?.[0]);
          el.click();
        }}
        className="flex min-h-14 items-center justify-center gap-2 rounded-xl bg-surface font-bold text-ink"
      >
        <ImagePlus className="size-5" />
        {t(language, "uploadPhoto")}
      </button>
      <button
        type="button"
        onClick={demo}
        className="flex min-h-14 items-center justify-center rounded-xl bg-surface-alt font-bold text-ink"
      >
        {t(language, "demoPhoto")}
      </button>
      {preview ? (
        <BigButton tone="secondary" onClick={() => keep(preview)}>
          {t(language, "keepPhoto")}
        </BigButton>
      ) : null}
    </div>
  );
}
