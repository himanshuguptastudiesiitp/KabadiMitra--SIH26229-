import { Link, useSearch } from "@tanstack/react-router";
import { Volume2 } from "lucide-react";
import { BigButton, Card, ScreenTitle } from "@/components/ui-bits";
import { inr } from "@/lib/format";
import { materialLabel, t } from "@/lib/i18n";
import { rateFor } from "@/lib/mock-data";
import { useAppStore } from "@/lib/store";
import { speak } from "@/lib/voice";

export function EstimateScreen() {
  const language = useAppStore((s) => s.language);
  const voiceOn = useAppStore((s) => s.voiceOn);
  const lots = useAppStore((s) => s.lots);
  const search = useSearch({ strict: false }) as { lot?: string };
  const lot = lots.find((l) => l.id === search.lot) ?? lots[0];
  if (!lot) return <p className="text-muted">{t(language, "noLots")}</p>;
  const row = rateFor(lot.category);
  const street = Math.round(lot.weightKg * (row.ratePerKg - 12));
  const text = `${materialLabel(language, lot.category)} ${lot.weightKg} kg. ${inr(lot.estimatedValue)}`;

  return (
    <div className="flex flex-col gap-4">
      <ScreenTitle title={t(language, "estimate")} sub={lot.id} />
      <Card className="bg-primary text-on-primary">
        <p className="text-sm font-bold opacity-90">{materialLabel(language, lot.category)}</p>
        <p className="mt-1 text-4xl font-extrabold tabular-nums">{inr(lot.estimatedValue)}</p>
        <p className="mt-1 text-sm opacity-90">
          {lot.weightKg} kg · {inr(lot.ratePerKg)} {t(language, "perKg")}
        </p>
      </Card>
      <Card>
        <p className="font-bold text-muted">{t(language, "streetRate")}</p>
        <p className="text-2xl font-extrabold text-ink">{inr(street)}</p>
        <p className="mt-1 text-success font-bold">
          {t(language, "betterBy")} {inr(lot.estimatedValue - street)}
        </p>
      </Card>
      {voiceOn ? (
        <button
          type="button"
          onClick={() => speak(text, language)}
          className="flex min-h-12 items-center justify-center gap-2 rounded-xl bg-surface font-bold text-ink"
        >
          <Volume2 className="size-5" />
          {t(language, "speakPrice")}
        </button>
      ) : null}
      <Link to="/recyclers" search={{ lot: lot.id }}>
        <BigButton>{t(language, "findRecycler")}</BigButton>
      </Link>
    </div>
  );
}
