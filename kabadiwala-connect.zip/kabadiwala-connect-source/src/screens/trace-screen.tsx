import { useSearch } from "@tanstack/react-router";
import { Card, ScreenTitle } from "@/components/ui-bits";
import { inr, shortDate } from "@/lib/format";
import { materialLabel, t } from "@/lib/i18n";
import { PIPELINE_STEPS, lotAmount, statusToStep } from "@/lib/pipeline";
import { RECYCLERS } from "@/lib/mock-data";
import { useAppStore } from "@/lib/store";

export function TraceScreen() {
  const language = useAppStore((s) => s.language);
  const lots = useAppStore((s) => s.lots);
  const search = useSearch({ strict: false }) as { lot?: string };
  const lot = lots.find((l) => l.id === search.lot) ?? lots[0];
  if (!lot) return <p className="text-muted">{t(language, "noLots")}</p>;
  const rec = RECYCLERS.find((r) => r.id === lot.recyclerId);
  const current = statusToStep(lot.status);

  return (
    <div className="flex flex-col gap-4">
      <ScreenTitle title={t(language, "traceLot")} sub={lot.id} />
      <Card>
        <p className="font-extrabold">{materialLabel(language, lot.category)}</p>
        <p className="text-muted">
          {lot.weightKg} kg · {lot.collectorName}
        </p>
        <p className="mt-1 text-2xl font-extrabold">{inr(lotAmount(lot))}</p>
        <p className="text-sm text-muted">{rec?.name ?? "—"}</p>
        {lot.handoverRef ? <p className="mt-1 font-bold">{lot.handoverRef}</p> : null}
      </Card>
      <ol className="flex flex-col gap-2">
        {PIPELINE_STEPS.map((step, i) => {
          const hit = lot.events.find((e) => e.step === step.id);
          const on = step.id === current;
          return (
            <li key={step.id}>
              <Card className={on ? "ring-2 ring-primary" : ""}>
                <p className="text-sm font-bold text-muted">{i + 1}</p>
                <p className="font-extrabold text-ink">{t(language, step.key)}</p>
                {hit ? (
                  <p className="text-sm text-muted">
                    {shortDate(hit.at, language)} {hit.note ? `· ${hit.note}` : ""}
                  </p>
                ) : (
                  <p className="text-sm text-disabled">{t(language, "notYet")}</p>
                )}
              </Card>
            </li>
          );
        })}
      </ol>
    </div>
  );
}
