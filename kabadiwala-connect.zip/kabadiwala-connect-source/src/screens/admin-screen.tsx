import { DeskSwitch } from "@/components/desk-switch";
import { PipelineStrip } from "@/components/pipeline-strip";
import { Card, ScreenTitle } from "@/components/ui-bits";
import { inr } from "@/lib/format";
import { materialLabel, t } from "@/lib/i18n";
import { ANOMALIES, COLLECTOR_NOTES, PRICE_BOARD, RECYCLERS } from "@/lib/mock-data";
import { lotAmount, statusToStep } from "@/lib/pipeline";
import { useAppStore } from "@/lib/store";
import { Link } from "@tanstack/react-router";

export function AdminScreen() {
  const language = useAppStore((s) => s.language);
  const lots = useAppStore((s) => s.lots);
  const kg = lots.reduce((s, l) => s + l.weightKg, 0);
  const cash = lots.filter((l) => l.paymentStatus === "paid").reduce((s, l) => s + lotAmount(l), 0);
  const pending = lots.filter((l) => l.paymentStatus !== "paid").length;

  return (
    <div className="flex flex-col gap-4 pb-6">
      <ScreenTitle title={t(language, "adminDesk")} sub={t(language, "adminDeskSub")} />
      <DeskSwitch />
      <PipelineStrip current="trace" />
      <div className="grid grid-cols-3 gap-2">
        <Stat label={t(language, "lots")} value={String(lots.length)} />
        <Stat label="kg" value={kg.toFixed(0)} />
        <Stat label={t(language, "paidDone")} value={inr(cash)} />
      </div>
      <Card>
        <p className="font-extrabold text-ink">{t(language, "materialFlow")}</p>
        <ul className="mt-2 flex flex-col gap-1">
          {PRICE_BOARD.map((row) => {
            const n = lots.filter((l) => l.category === row.category).reduce((s, l) => s + l.weightKg, 0);
            return (
              <li key={row.category} className="flex justify-between text-sm">
                <span>{materialLabel(language, row.category)}</span>
                <span className="font-bold">{n.toFixed(1)} kg</span>
              </li>
            );
          })}
        </ul>
      </Card>
      <Card>
        <p className="font-extrabold text-ink">{t(language, "collectors")}</p>
        <ul className="mt-2 flex flex-col gap-2">
          {COLLECTOR_NOTES.map((c) => (
            <li key={c.id} className="flex justify-between">
              <span>
                {c.name}
                <span className="block text-xs text-muted">{c.area}</span>
              </span>
              <span className="font-extrabold">{inr(c.earned)}</span>
            </li>
          ))}
        </ul>
      </Card>
      <Card>
        <p className="font-extrabold text-ink">{t(language, "authorize")}</p>
        <ul className="mt-2 flex flex-col gap-2">
          {RECYCLERS.map((r) => (
            <li key={r.id} className="flex items-center justify-between">
              <span>
                {r.name}
                <span className="block text-xs text-muted">{r.area}</span>
              </span>
              <span className={`text-sm font-bold ${r.authorized ? "text-success" : "text-danger"}`}>
                {r.authorized ? t(language, "authorized") : t(language, "notAuthorized")}
              </span>
            </li>
          ))}
        </ul>
      </Card>
      <Card>
        <p className="font-extrabold text-ink">{t(language, "alerts")}</p>
        <p className="text-sm text-muted">{t(language, "pendingLots")}: {pending}</p>
        <ul className="mt-2 flex flex-col gap-2">
          {ANOMALIES.map((a) => (
            <li key={a.id} className="rounded-lg bg-surface-alt p-2 text-sm font-bold text-warning">
              {a.lotId} · {t(language, a.textKey)}
            </li>
          ))}
        </ul>
      </Card>
      <Card>
        <p className="font-extrabold text-ink">{t(language, "geo")}</p>
        <ul className="mt-2 flex flex-col gap-1 text-sm">
          {lots.slice(0, 6).map((l) => (
            <li key={l.id} className="flex justify-between">
              <span>{l.location.label}</span>
              <span className="font-bold">{statusToStep(l.status)}</span>
            </li>
          ))}
        </ul>
      </Card>
      <Link to="/trace" className="flex min-h-14 items-center justify-center rounded-xl bg-primary font-bold text-on-primary">
        {t(language, "traceLot")}
      </Link>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <Card className="p-3">
      <p className="text-xs font-bold text-muted">{label}</p>
      <p className="text-xl font-extrabold tabular-nums text-ink">{value}</p>
    </Card>
  );
}
