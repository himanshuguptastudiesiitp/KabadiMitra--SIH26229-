import { useSearch } from "@tanstack/react-router";
import { useNavigate } from "@tanstack/react-router";
import { BigButton, Card, ScreenTitle } from "@/components/ui-bits";
import { inr, kmLabel } from "@/lib/format";
import { materialLabel, t } from "@/lib/i18n";
import { RECYCLERS, rateFor } from "@/lib/mock-data";
import { useAppStore } from "@/lib/store";

export function RecyclersScreen() {
  const language = useAppStore((s) => s.language);
  const lots = useAppStore((s) => s.lots);
  const offerLot = useAppStore((s) => s.offerLot);
  const acceptOffer = useAppStore((s) => s.acceptOffer);
  const navigate = useNavigate();
  const search = useSearch({ strict: false }) as { lot?: string };
  const lot = lots.find((l) => l.id === search.lot) ?? lots.find((l) => l.status !== "paid");
  const list = RECYCLERS.filter((r) => !lot || r.materials.includes(lot.category)).sort(
    (a, b) => Number(b.authorized) - Number(a.authorized) || a.km - b.km,
  );

  function pick(recyclerId: string) {
    if (!lot) return;
    const rec = RECYCLERS.find((r) => r.id === recyclerId);
    const base = rateFor(lot.category).ratePerKg + (rec?.rateBonus ?? 0);
    offerLot(lot.id, recyclerId, Math.round(lot.weightKg * base));
  }

  function goHandover() {
    if (!lot) return;
    if (lot.status === "offered") acceptOffer(lot.id);
    void navigate({ to: "/handover", search: { lot: lot.id } });
  }

  return (
    <div className="flex flex-col gap-4">
      <ScreenTitle title={t(language, "recyclers")} sub={t(language, "recyclerSub")} />
      {lot ? (
        <p className="text-muted">
          {materialLabel(language, lot.category)} · {lot.weightKg} kg · {inr(lot.estimatedValue)}
        </p>
      ) : null}
      <ul className="flex flex-col gap-3">
        {list.map((r) => {
          const selected = lot?.recyclerId === r.id;
          const price = lot ? Math.round(lot.weightKg * (rateFor(lot.category).ratePerKg + r.rateBonus)) : 0;
          return (
            <li key={r.id}>
              <button type="button" onClick={() => pick(r.id)} className="w-full text-left">
                <Card className={selected ? "ring-2 ring-primary" : ""}>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <p className="text-lg font-extrabold text-ink">{r.name}</p>
                      <p className="text-sm text-muted">
                        {r.area} · {kmLabel(r.km)} km
                      </p>
                      <p className={`mt-1 text-sm font-bold ${r.authorized ? "text-success" : "text-danger"}`}>
                        {r.authorized ? t(language, "authorized") : t(language, "notAuthorized")}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-xl font-extrabold tabular-nums text-ink">{inr(price)}</p>
                      <p className="text-xs text-muted">{r.pickup ? t(language, "pickupYes") : t(language, "pickupNo")}</p>
                    </div>
                  </div>
                </Card>
              </button>
            </li>
          );
        })}
      </ul>
      <BigButton disabled={!lot?.recyclerId} onClick={goHandover}>
        {t(language, "makeReceipt")}
      </BigButton>
    </div>
  );
}
