import { BatteryCharging, Droplets, Flame, Tv, Volume2 } from "lucide-react";
import { Card, ScreenTitle } from "@/components/ui-bits";
import { t, type I18nKey } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";
import { speak } from "@/lib/voice";

const TIPS: { icon: typeof Flame; title: I18nKey; body: I18nKey }[] = [
  { icon: Flame, title: "tipBurnTitle", body: "tipBurnBody" },
  { icon: BatteryCharging, title: "tipBattTitle", body: "tipBattBody" },
  { icon: Tv, title: "tipCrtTitle", body: "tipCrtBody" },
  { icon: Droplets, title: "tipPcbTitle", body: "tipPcbBody" },
];

export function SafetyScreen() {
  const language = useAppStore((s) => s.language);
  const voiceOn = useAppStore((s) => s.voiceOn);

  return (
    <div className="flex flex-col gap-4">
      <ScreenTitle title={t(language, "safety")} sub={t(language, "safetyLead")} />
      {voiceOn ? (
        <button
          type="button"
          onClick={() => speak(TIPS.map((tip) => `${t(language, tip.title)}. ${t(language, tip.body)}`).join(" "), language)}
          className="flex min-h-12 items-center justify-center gap-2 rounded-xl bg-secondary font-bold text-on-secondary"
        >
          <Volume2 className="size-5" />
          {t(language, "speakSafety")}
        </button>
      ) : null}
      <ul className="flex flex-col gap-3">
        {TIPS.map((tip) => {
          const Icon = tip.icon;
          return (
            <li key={tip.title}>
              <Card className="flex gap-3">
                <div className="flex size-14 shrink-0 items-center justify-center rounded-xl bg-warning text-on-primary">
                  <Icon className="size-7" />
                </div>
                <div>
                  <p className="text-lg font-extrabold text-ink">{t(language, tip.title)}</p>
                  <p className="mt-1 text-base text-muted">{t(language, tip.body)}</p>
                </div>
              </Card>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
