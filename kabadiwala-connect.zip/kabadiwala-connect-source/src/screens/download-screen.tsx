import { PhoneChrome } from "@/components/phone-chrome";
import { t } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";

export function DownloadScreen() {
  const language = useAppStore((s) => s.language);
  return (
    <PhoneChrome>
      <div className="flex min-h-full flex-col gap-4">
        <h1 className="text-3xl font-extrabold text-ink">{t(language, "downloadTitle")}</h1>
        <p className="text-lg text-muted">{t(language, "downloadSub")}</p>
        <a
          href="/kabadiwala-connect.zip"
          download
          className="flex min-h-16 items-center justify-center rounded-xl bg-btn-primary text-lg font-extrabold text-btn-primary-fg"
        >
          {t(language, "downloadZip")}
        </a>
        <a
          href="/ALL-CODE.txt"
          download
          className="flex min-h-16 items-center justify-center rounded-xl bg-btn-secondary text-lg font-extrabold text-btn-secondary-fg"
        >
          {t(language, "downloadText")}
        </a>
      </div>
    </PhoneChrome>
  );
}
