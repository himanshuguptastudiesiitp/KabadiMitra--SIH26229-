import { Link } from "@tanstack/react-router";
import { Check } from "lucide-react";
import { ScreenTitle } from "@/components/ui-bits";
import { t } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";
import { THEMES } from "@/theme/app-theme";

export function ThemeScreen() {
  const language = useAppStore((s) => s.language);
  const themeId = useAppStore((s) => s.themeId);
  const setThemeId = useAppStore((s) => s.setThemeId);

  return (
    <div className="flex flex-col gap-4 pb-8">
      <ScreenTitle title={t(language, "themeTitle")} sub={t(language, "themeSub")} />
      <ul className="flex flex-col gap-3">
        {THEMES.map((theme) => {
          const selected = theme.id === themeId;
          return (
            <li key={theme.id}>
              <button
                type="button"
                onClick={() => setThemeId(theme.id)}
                className={`w-full overflow-hidden rounded-xl bg-surface text-left shadow-sm ${
                  selected ? "ring-2 ring-primary ring-offset-2 ring-offset-background" : ""
                }`}
              >
                <div className="grid h-14 grid-cols-4">
                  {theme.plate.map((hex) => (
                    <span key={hex} className="block h-full" style={{ backgroundColor: hex }} />
                  ))}
                </div>
                <div className="flex items-center justify-between gap-3 px-4 py-3">
                  <div>
                    <p className="text-lg font-extrabold text-ink">{theme.name[language]}</p>
                    {selected ? <p className="text-sm font-bold text-primary">{t(language, "themeNow")}</p> : null}
                  </div>
                  {selected ? (
                    <span className="flex size-9 items-center justify-center rounded-full bg-primary text-on-primary">
                      <Check className="size-5" strokeWidth={3} />
                    </span>
                  ) : null}
                </div>
              </button>
            </li>
          );
        })}
      </ul>
      <Link to="/settings" className="flex min-h-14 items-center justify-center rounded-xl bg-surface-alt font-bold text-ink">
        {t(language, "back")}
      </Link>
    </div>
  );
}
