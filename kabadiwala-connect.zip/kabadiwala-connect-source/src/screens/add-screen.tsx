import { useMemo, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Minus, Plus } from "lucide-react";
import { MATERIAL_ICON } from "@/components/icons";
import { BigButton, ScreenTitle } from "@/components/ui-bits";
import { getClassifier } from "@/lib/classify";
import { materialLabel, t } from "@/lib/i18n";
import { MATERIAL_ORDER, NAGPUR, rateFor } from "@/lib/mock-data";
import { useAppStore } from "@/lib/store";
import type { MaterialId } from "@/lib/types";

export function AddScreen() {
  const language = useAppStore((s) => s.language);
  const pendingPhoto = useAppStore((s) => s.pendingPhoto);
  const displayName = useAppStore((s) => s.displayName);
  const addLot = useAppStore((s) => s.addLot);
  const navigate = useNavigate();
  const [category, setCategory] = useState<MaterialId>("pcb");
  const [kg, setKg] = useState(4);
  const [guessing, setGuessing] = useState(false);
  const row = rateFor(category);
  const value = useMemo(() => Math.round(kg * row.ratePerKg), [kg, row.ratePerKg]);

  async function guess() {
    if (!pendingPhoto) return;
    setGuessing(true);
    const result = await getClassifier().classify(pendingPhoto);
    setCategory(result.category);
    setGuessing(false);
  }

  function save() {
    const lot = addLot({
      category,
      weightKg: kg,
      photoDataUrl: pendingPhoto,
      estimatedValue: value,
      ratePerKg: row.ratePerKg,
      quotedPrice: value,
      status: "valued",
      location: NAGPUR,
      paymentMethod: "cash",
      paymentStatus: "none",
      collectorName: displayName || t(language, "sampleName"),
      collectorArea: NAGPUR.label,
      pickupStatus: "none",
    });
    void navigate({ to: "/estimate", search: { lot: lot.id } });
  }

  return (
    <div className="flex flex-col gap-4">
      <ScreenTitle title={t(language, "addScrap")} sub={t(language, "addSub")} />
      <div className="overflow-hidden rounded-xl bg-surface-alt">
        {pendingPhoto ? (
          <img src={pendingPhoto} alt="" className="h-40 w-full object-cover" />
        ) : (
          <button
            type="button"
            onClick={() => void navigate({ to: "/camera" })}
            className="flex h-40 w-full items-center justify-center font-bold text-muted"
          >
            {t(language, "openCamera")}
          </button>
        )}
      </div>
      {pendingPhoto ? (
        <button
          type="button"
          onClick={() => void guess()}
          className="min-h-12 rounded-xl bg-surface font-bold text-primary"
        >
          {guessing ? t(language, "working") : t(language, "aiGuess")}
        </button>
      ) : null}
      <p className="font-extrabold text-ink">{t(language, "pickType")}</p>
      <div className="grid grid-cols-2 gap-2">
        {MATERIAL_ORDER.map((id) => {
          const Icon = MATERIAL_ICON[id];
          const on = id === category;
          return (
            <button
              key={id}
              type="button"
              onClick={() => setCategory(id)}
              className={`flex min-h-16 items-center gap-2 rounded-xl px-3 text-left font-bold ${
                on ? "bg-primary text-on-primary" : "bg-surface text-ink"
              }`}
            >
              <Icon className="size-6" />
              {materialLabel(language, id)}
            </button>
          );
        })}
      </div>
      <p className="font-extrabold text-ink">{t(language, "weight")}</p>
      <div className="flex items-center justify-between rounded-xl bg-surface p-3">
        <button
          type="button"
          className="flex size-14 items-center justify-center rounded-xl bg-surface-alt"
          onClick={() => setKg((n) => Math.max(0.5, +(n - 0.5).toFixed(1)))}
        >
          <Minus />
        </button>
        <p className="text-4xl font-extrabold tabular-nums text-ink">{kg} kg</p>
        <button
          type="button"
          className="flex size-14 items-center justify-center rounded-xl bg-surface-alt"
          onClick={() => setKg((n) => +(n + 0.5).toFixed(1))}
        >
          <Plus />
        </button>
      </div>
      <p className="text-center text-lg text-muted">
        {t(language, "roughValue")}: ₹{value}
      </p>
      <BigButton onClick={save}>{t(language, "next")}</BigButton>
    </div>
  );
}
