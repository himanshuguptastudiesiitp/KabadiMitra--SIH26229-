import { useState } from "react";
import { DeskSwitch } from "@/components/desk-switch";
import { PipelineStrip } from "@/components/pipeline-strip";
import { BigButton, Card, ScreenTitle } from "@/components/ui-bits";
import { inr } from "@/lib/format";
import { materialLabel, t } from "@/lib/i18n";
import { lotAmount } from "@/lib/pipeline";
import { useAppStore } from "@/lib/store";
import type { Lot } from "@/lib/types";

const TABS = ["in", "pickup", "done"] as const;

export function RecyclerScreen() {
  const language = useAppStore((s) => s.language);
  const lots = useAppStore((s) => s.lots);
  const offerLot = useAppStore((s) => s.offerLot);
  const setPickup = useAppStore((s) => s.setPickup);
  const verifyLot = useAppStore((s) => s.verifyLot);
  const payLot = useAppStore((s) => s.payLot);
  const rejectOffer = useAppStore((s) => s.rejectOffer);
  const [tab, setTab] = useState<(typeof TABS)[number]>("in");
  const [offer, setOffer] = useState<Record<string, number>>({});

  const incoming = lots.filter((l) => ["valued", "matched", "offered", "accepted"].includes(l.status));
  const pickup = lots.filter((l) => l.status === "handed" || l.pickupStatus === "scheduled" || l.pickupStatus === "requested");
  const done = lots.filter((l) => l.status === "verified" || l.status === "paid");
  const shown = tab === "in" ? incoming : tab === "pickup" ? pickup : done;

  function onOffer(lot: Lot) {
    const price = offer[lot.id] || lotAmount(lot);
    offerLot(lot.id, lot.recyclerId ?? "r1", price);
  }

  return (
    <div className="flex flex-col gap-4 pb-6">
      <ScreenTitle title={t(language, "recyclerDesk")} sub={t(language, "recyclerDeskSub")} />
      <DeskSwitch />
      <PipelineStrip current="matched" />
      <div className="grid grid-cols-3 gap-2">
        {TABS.map((id) => (
          <button
            key={id}
            type="button"
            onClick={() => setTab(id)}
            className={`min-h-12 rounded-xl text-sm font-bold ${tab === id ? "bg-primary text-on-primary" : "bg-surface text-ink"}`}
          >
            {id === "in" ? t(language, "incoming") : id === "pickup" ? t(language, "pickupTab") : t(language, "doneTab")}
          </button>
        ))}
      </div>
      {shown.length === 0 ? <p className="text-muted">{t(language, "noLots")}</p> : null}
      <ul className="flex flex-col gap-3">
        {shown.map((lot) => (
          <li key={lot.id}>
            <Card>
              <p className="font-extrabold text-ink">
                {lot.id} · {materialLabel(language, lot.category)}
              </p>
              <p className="text-sm text-muted">
                {lot.weightKg} kg · {lot.collectorName} · {lot.location.label}
              </p>
              <p className="mt-1 text-2xl font-extrabold tabular-nums">{inr(lotAmount(lot))}</p>
              {tab === "in" ? (
                <div className="mt-3 flex flex-col gap-2">
                  <label className="text-sm font-bold text-muted">{t(language, "offerPrice")}</label>
                  <input
                    type="number"
                    className="min-h-12 rounded-xl border border-line bg-background px-3 text-lg font-bold text-ink"
                    value={offer[lot.id] ?? lotAmount(lot)}
                    onChange={(e) => setOffer((m) => ({ ...m, [lot.id]: Number(e.target.value) }))}
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <BigButton onClick={() => onOffer(lot)}>{t(language, "sendOffer")}</BigButton>
                    <button
                      type="button"
                      onClick={() => rejectOffer(lot.id)}
                      className="min-h-14 rounded-xl bg-surface-alt font-bold text-danger"
                    >
                      {t(language, "reject")}
                    </button>
                  </div>
                  <button
                    type="button"
                    onClick={() => setPickup(lot.id, "scheduled")}
                    className="min-h-12 rounded-xl bg-surface font-bold text-ink"
                  >
                    {t(language, "schedulePickup")}
                  </button>
                </div>
              ) : null}
              {tab === "pickup" ? (
                <div className="mt-3 flex flex-col gap-2">
                  <label className="text-sm font-bold text-muted">{t(language, "receivedKg")}</label>
                  <input
                    type="number"
                    defaultValue={lot.weightKg}
                    id={`kg-${lot.id}`}
                    className="min-h-12 rounded-xl border border-line bg-background px-3 text-lg font-bold"
                  />
                  <BigButton
                    onClick={() => {
                      const el = document.getElementById(`kg-${lot.id}`) as HTMLInputElement;
                      verifyLot(lot.id, Number(el?.value || lot.weightKg));
                    }}
                  >
                    {t(language, "confirmWeigh")}
                  </BigButton>
                </div>
              ) : null}
              {tab === "done" && lot.paymentStatus !== "paid" ? (
                <BigButton
                  tone="secondary"
                  onClick={() => payLot(lot.id, lot.paymentMethod, lot.finalPrice ?? lotAmount(lot))}
                >
                  {t(language, "markPaid")}
                </BigButton>
              ) : null}
              {lot.paymentStatus === "paid" ? (
                <p className="mt-2 font-bold text-success">{t(language, "paidDone")}</p>
              ) : null}
            </Card>
          </li>
        ))}
      </ul>
    </div>
  );
}
