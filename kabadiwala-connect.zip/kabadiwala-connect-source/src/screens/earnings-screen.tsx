import { Card, ScreenTitle } from "@/components/ui-bits";
import { inr, shortDate } from "@/lib/format";
import { materialLabel, t } from "@/lib/i18n";
import { lotAmount } from "@/lib/pipeline";
import { useAppStore } from "@/lib/store";

export function EarningsScreen() {
  const language = useAppStore((s) => s.language);
  const lots = useAppStore((s) => s.lots);
  const paid = lots.filter((l) => l.paymentStatus === "paid");
  const pending = lots.filter((l) => l.paymentStatus === "pending");
  const paidSum = paid.reduce((s, l) => s + lotAmount(l), 0);
  const pendingSum = pending.reduce((s, l) => s + lotAmount(l), 0);

  return (
    <div className="flex flex-col gap-4">
      <ScreenTitle title={t(language, "earnings")} sub={t(language, "ledgerSub")} />
      <div className="grid grid-cols-2 gap-2">
        <Card className="bg-primary text-on-primary">
          <p className="text-sm">{t(language, "paidDone")}</p>
          <p className="text-3xl font-extrabold">{inr(paidSum)}</p>
        </Card>
        <Card>
          <p className="text-sm text-muted">{t(language, "pendingPay")}</p>
          <p className="text-3xl font-extrabold text-warning">{inr(pendingSum)}</p>
        </Card>
      </div>
      <h2 className="font-extrabold">{t(language, "history")}</h2>
      <ul className="flex flex-col gap-2">
        {[...paid, ...pending].map((lot) => (
          <li key={lot.id}>
            <Card className="flex items-center justify-between">
              <div>
                <p className="font-extrabold">{materialLabel(language, lot.category)}</p>
                <p className="text-sm text-muted">
                  {shortDate(lot.createdAt, language)} · {lot.paymentMethod === "cash" ? t(language, "cash") : t(language, "upi")}
                </p>
              </div>
              <div className="text-right">
                <p className="text-xl font-extrabold">{inr(lotAmount(lot))}</p>
                <p className={`text-xs font-bold ${lot.paymentStatus === "paid" ? "text-success" : "text-warning"}`}>
                  {lot.paymentStatus === "paid" ? t(language, "paidDone") : t(language, "pendingPay")}
                </p>
              </div>
            </Card>
          </li>
        ))}
      </ul>
    </div>
  );
}
