import { Link } from "@tanstack/react-router";
import { Camera, ShieldAlert, Store, Tag, UserRound, Wallet } from "lucide-react";
import { DeskSwitch } from "@/components/desk-switch";
import { LotCard } from "@/components/lot-card";
import { NextStepCard } from "@/components/next-step";
import { PipelineStrip } from "@/components/pipeline-strip";
import { Card } from "@/components/ui-bits";
import { useCurrentUser } from "@/lib/auth/use-current-user";
import { inr } from "@/lib/format";
import { t } from "@/lib/i18n";
import { lotAmount, pickActiveLot } from "@/lib/pipeline";
import { useAppStore } from "@/lib/store";
import { useClientReady } from "@/lib/use-client-ready";

export function HomeScreen() {
  const ready = useClientReady();
  const language = useAppStore((s) => s.language);
  const lots = useAppStore((s) => s.lots);
  const displayName = useAppStore((s) => s.displayName);
  const user = useCurrentUser();
  const name = displayName || user?.displayName || t(language, "sampleName");
  const today = ready ? new Date().toDateString() : "";
  const todaySum = ready
    ? lots
        .filter((l) => new Date(l.createdAt).toDateString() === today && l.paymentStatus === "paid")
        .reduce((s, l) => s + lotAmount(l), 0)
    : 0;
  const paidFallback = ready
    ? lots.filter((l) => l.paymentStatus === "paid").slice(0, 2).reduce((s, l) => s + (l.finalPrice ?? 0), 0)
    : 0;
  const shown = todaySum || paidFallback;
  const recent = ready ? lots.slice(0, 5) : [];
  const active = pickActiveLot(lots);

  return (
    <div className="flex flex-col gap-4">
      <div>
        <p className="text-base font-semibold text-muted">
          {t(language, "ramRam")}, {name}
        </p>
        <h1 className="text-3xl font-extrabold leading-tight text-ink">{t(language, "appName")}</h1>
        <p className="mt-1 text-base text-muted">{t(language, "chainSub")}</p>
      </div>
      <DeskSwitch />
      <PipelineStrip current={active?.status ?? "collected"} />
      <NextStepCard lot={active} />
      <Card className="bg-primary text-on-primary">
        <p className="text-sm font-bold opacity-90">{t(language, "todayEarned")}</p>
        <p className="mt-1 font-extrabold tabular-nums text-4xl">{inr(shown)}</p>
      </Card>
      <Link
        to="/camera"
        className="flex min-h-14 w-full items-center justify-center gap-2 rounded-xl bg-btn-secondary text-lg font-bold text-btn-secondary-fg"
      >
        <Camera className="size-5" />
        {t(language, "openCamera")}
      </Link>
      <div className="grid grid-cols-2 gap-3">
        <Quick to="/add" icon={Camera} label={t(language, "addScrap")} />
        <Quick to="/prices" icon={Tag} label={t(language, "priceBoard")} />
        <Quick to="/earnings" icon={Wallet} label={t(language, "earnings")} />
        <Quick to="/recyclers" icon={Store} label={t(language, "recyclers")} />
        <Quick to="/safety" icon={ShieldAlert} label={t(language, "safety")} />
        <Quick to="/user" icon={UserRound} label={t(language, "userPage")} />
      </div>
      <section>
        <h2 className="mb-2 text-lg font-extrabold text-ink">{t(language, "recentLots")}</h2>
        {recent.length === 0 ? (
          <p className="text-muted">{t(language, "noLots")}</p>
        ) : (
          <ul className="flex flex-col gap-2">
            {recent.map((lot) => (
              <li key={lot.id}>
                <LotCard lot={lot} />
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}

function Quick({
  to,
  icon: Icon,
  label,
}: {
  to: "/add" | "/prices" | "/earnings" | "/recyclers" | "/safety" | "/user";
  icon: typeof Tag;
  label: string;
}) {
  return (
    <Link to={to} className="flex min-h-24 flex-col items-start justify-between rounded-xl bg-surface p-3 shadow-sm">
      <Icon className="size-7 text-secondary" strokeWidth={2.3} />
      <span className="text-left text-base font-extrabold leading-snug text-ink">{label}</span>
    </Link>
  );
}
