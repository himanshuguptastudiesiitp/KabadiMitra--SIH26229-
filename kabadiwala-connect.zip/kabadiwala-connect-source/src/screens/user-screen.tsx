import { Link } from "@tanstack/react-router";
import { DeskSwitch } from "@/components/desk-switch";
import { LotCard } from "@/components/lot-card";
import { NextStepCard } from "@/components/next-step";
import { PipelineStrip } from "@/components/pipeline-strip";
import { Card, ScreenTitle } from "@/components/ui-bits";
import { inr } from "@/lib/format";
import { t } from "@/lib/i18n";
import { lotAmount, pickActiveLot } from "@/lib/pipeline";
import { useAppStore } from "@/lib/store";

export function UserScreen() {
  const language = useAppStore((s) => s.language);
  const lots = useAppStore((s) => s.lots);
  const displayName = useAppStore((s) => s.displayName);
  const photos = useAppStore((s) => s.photos);
  const pending = lots.filter((l) => l.paymentStatus !== "paid");
  const paid = lots.filter((l) => l.paymentStatus === "paid");
  const total = paid.reduce((s, l) => s + lotAmount(l), 0);
  const active = pickActiveLot(lots);

  return (
    <div className="flex flex-col gap-4">
      <ScreenTitle title={t(language, "userPage")} sub={displayName || t(language, "sampleName")} />
      <DeskSwitch />
      <PipelineStrip current={active?.status ?? "collected"} />
      <NextStepCard lot={active} />
      <div className="grid grid-cols-2 gap-2">
        <Card>
          <p className="text-sm text-muted">{t(language, "paidDone")}</p>
          <p className="text-2xl font-extrabold">{inr(total)}</p>
        </Card>
        <Card>
          <p className="text-sm text-muted">{t(language, "pendingLots")}</p>
          <p className="text-2xl font-extrabold">{pending.length}</p>
        </Card>
      </div>
      <Link to="/camera" className="flex min-h-14 items-center justify-center rounded-xl bg-btn-secondary font-bold text-btn-secondary-fg">
        {t(language, "openCamera")}
      </Link>
      <h2 className="font-extrabold">{t(language, "recentLots")}</h2>
      <ul className="flex flex-col gap-2">
        {lots.slice(0, 8).map((lot) => (
          <li key={lot.id}>
            <LotCard lot={lot} />
          </li>
        ))}
      </ul>
      {photos.length ? (
        <div>
          <h2 className="mb-2 font-extrabold">{t(language, "myPhotos")}</h2>
          <div className="grid grid-cols-3 gap-2">
            {photos.slice(0, 6).map((p) => (
              <img key={p.id} src={p.dataUrl} alt="" className="h-20 w-full rounded-lg object-cover" />
            ))}
          </div>
        </div>
      ) : null}
    </div>
  );
}
