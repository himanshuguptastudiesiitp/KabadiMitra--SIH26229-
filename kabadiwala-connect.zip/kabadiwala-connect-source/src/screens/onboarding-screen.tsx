import { useNavigate } from "@tanstack/react-router";
import { PhoneChrome } from "@/components/phone-chrome";
import { PipelineStrip } from "@/components/pipeline-strip";
import { BigButton } from "@/components/ui-bits";
import { t } from "@/lib/i18n";
import { homePath } from "@/lib/pipeline";
import { useAppStore } from "@/lib/store";
import type { UserRole } from "@/lib/types";

const ROLES: UserRole[] = ["collector", "recycler", "admin"];

export function OnboardingScreen() {
  const language = useAppStore((s) => s.language);
  const role = useAppStore((s) => s.role);
  const setRole = useAppStore((s) => s.setRole);
  const applyProfile = useAppStore((s) => s.applyProfile);
  const displayName = useAppStore((s) => s.displayName);
  const navigate = useNavigate();

  function go() {
    applyProfile({
      onboardingDone: true,
      displayName: displayName || t(language, "sampleName"),
      role,
    });
    void navigate({ to: homePath(role) });
  }

  return (
    <PhoneChrome>
      <div className="flex flex-col gap-4 pb-4">
        <p className="text-sm font-bold text-muted">{t(language, "sih")}</p>
        <h1 className="text-3xl font-extrabold leading-tight text-ink">{t(language, "appName")}</h1>
        <p className="text-base text-muted">{t(language, "chainSub")}</p>
        <PipelineStrip current="collect" />
        <ol className="flex flex-col gap-2 text-base font-bold text-ink">
          <li>1. {t(language, "stepCollect")}</li>
          <li>2. {t(language, "stepIdentify")}</li>
          <li>3. {t(language, "stepValue")}</li>
          <li>4. {t(language, "stepMatch")}</li>
          <li>5. {t(language, "stepHandover")}</li>
          <li>6. {t(language, "stepVerify")}</li>
          <li>7. {t(language, "stepPaid")}</li>
          <li>8. {t(language, "stepTrace")}</li>
        </ol>
        <p className="font-extrabold">{t(language, "pickRole")}</p>
        <div className="grid grid-cols-3 gap-2">
          {ROLES.map((r) => (
            <button
              key={r}
              type="button"
              onClick={() => setRole(r)}
              className={`min-h-16 rounded-xl px-1 text-sm font-extrabold ${
                role === r ? "bg-primary text-on-primary" : "bg-surface text-ink"
              }`}
            >
              {r === "collector" ? t(language, "roleCollector") : r === "recycler" ? t(language, "roleRecycler") : t(language, "roleAdmin")}
            </button>
          ))}
        </div>
        <BigButton onClick={go}>{t(language, "next")}</BigButton>
        <a href="/kabadiwala-connect.zip" download className="flex min-h-14 items-center justify-center rounded-xl bg-btn-secondary font-extrabold text-btn-secondary-fg">
          {t(language, "downloadZip")}
        </a>
        <a href="/ALL-CODE.txt" download className="flex min-h-14 items-center justify-center rounded-xl bg-surface font-bold text-ink">
          {t(language, "downloadText")}
        </a>
      </div>
    </PhoneChrome>
  );
}
