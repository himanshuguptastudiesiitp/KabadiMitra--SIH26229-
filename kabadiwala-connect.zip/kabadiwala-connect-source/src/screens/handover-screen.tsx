import { useState } from "react";
import { Link, useSearch } from "@tanstack/react-router";
import { BigButton, Card, ScreenTitle } from "@/components/ui-bits";
import { inr } from "@/lib/format";
import { materialLabel, t } from "@/lib/i18n";
import { RECYCLERS } from "@/lib/mock-data";
import { lotAmount } from "@/lib/pipeline";
import { useAppStore } from "@/lib/store";
import type { PayMethod } from "@/lib/types";

export function HandoverScreen() {
  const language = useAppStore((s) => s.language);
  const lots = useAppStore((s) => s.lots);
  const handoverLot = useAppStore((s) => s.handoverLot);
  const search = useSearch({ strict: false }) as { lot?: string };
  const lot = lots.find((l) => l.id === search.lot) ?? lots.find((l) => l.status === "accepted" || l.status === "offered");
  const [method, setMethod] = useState<PayMethod>("cash");
  const rec = RECYCLERS.find((r) => r.id === lot?.recyclerId);

  if (!lot) return <p className="text-muted">{t(language, "noLots")}</p>;

  const ref = lot.handoverRef;
  const amount = lotAmount(lot);

  return (
    <div className="flex flex-col gap-4">
      <ScreenTitle title={t(language, "handover")} sub={lot.id} />
      <Card>
        <p className="font-extrabold text-ink">{materialLabel(language, lot.category)}</p>
        <p className="text-muted">
          {lot.weightKg} kg · {rec?.name}
        </p>
        <p className="mt-2 text-3xl font-extrabold tabular-nums">{inr(amount)}</p>
      </Card>
      <p className="font-extrabold">{t(language, "payHow")}</p>
      <div className="grid grid-cols-2 gap-2">
        <button
          type="button"
          onClick={() => setMethod("cash")}
          className={`min-h-14 rounded-xl font-bold ${method === "cash" ? "bg-primary text-on-primary" : "bg-surface"}`}
        >
          {t(language, "cash")}
        </button>
        <button
          type="button"
          onClick={() => setMethod("upi")}
          className={`min-h-14 rounded-xl font-bold ${method === "upi" ? "bg-primary text-on-primary" : "bg-surface"}`}
        >
          {t(language, "upi")}
        </button>
      </div>
      {!ref ? (
        <BigButton onClick={() => handoverLot(lot.id, method)}>{t(language, "makeReceipt")}</BigButton>
      ) : (
        <Card className="bg-primary text-on-primary">
          <p className="text-sm opacity-90">{t(language, "receiptNo")}</p>
          <p className="text-3xl font-extrabold">{ref}</p>
          <div className="mx-auto mt-3 grid size-28 grid-cols-5 grid-rows-5 gap-1 bg-on-primary p-2">
            {Array.from({ length: 25 }).map((_, i) => (
              <span key={i} className={ref.charCodeAt(i % ref.length) % 2 ? "bg-primary" : "bg-transparent"} />
            ))}
          </div>
          <p className="mt-2 text-center text-sm">{t(language, "showAtYard")}</p>
        </Card>
      )}
      <Link to="/" className="flex min-h-12 items-center justify-center font-bold text-primary">
        {t(language, "back")}
      </Link>
    </div>
  );
}
