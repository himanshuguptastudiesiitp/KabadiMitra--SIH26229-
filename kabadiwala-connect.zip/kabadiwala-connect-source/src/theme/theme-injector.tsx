import { useEffect } from "react";
import { useAppStore } from "@/lib/store";
import { getTheme, themeCssText } from "@/theme/app-theme";

export function ThemeInjector() {
  const themeId = useAppStore((s) => s.themeId);
  const theme = getTheme(themeId);

  useEffect(() => {
    void useAppStore.persist.rehydrate();
  }, []);

  useEffect(() => {
    document.documentElement.style.colorScheme = theme.scheme;
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute("content", theme.colors.primary);
  }, [theme]);

  return <style id="kc-theme">{themeCssText(theme)}</style>;
}
