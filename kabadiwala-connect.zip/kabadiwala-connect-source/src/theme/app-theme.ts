/**
 * Kabadiwala Connect — single theme file.
 * Screens must not hardcode hex.
 */
import type { Lang } from "@/lib/types";

export type AppColorSet = {
  primary: string;
  primaryDark: string;
  primaryLight: string;
  secondary: string;
  accent: string;
  background: string;
  surface: string;
  surfaceAlt: string;
  ink: string;
  muted: string;
  disabled: string;
  onPrimary: string;
  onSecondary: string;
  success: string;
  danger: string;
  warning: string;
  buttonPrimary: string;
  buttonPrimaryText: string;
  buttonSecondary: string;
  buttonSecondaryText: string;
  buttonDisabled: string;
  line: string;
  overlay: string;
};

export type ThemeId = "field" | "paper" | "night" | "jamun" | "pudina" | "chai" | "gulab";

export type AppThemeDef = {
  id: ThemeId;
  name: Record<Lang, string>;
  plate: [string, string, string, string];
  scheme: "light" | "dark";
  colors: AppColorSet;
};

const FIELD: AppThemeDef = {
  id: "field",
  name: { hi: "मैदान हरा", mr: "मैदान हिरवा", en: "Field green" },
  plate: ["#1F4D3A", "#C45C26", "#F3EDE3", "#D4A017"],
  scheme: "light",
  colors: {
    primary: "#1F4D3A",
    primaryDark: "#16382B",
    primaryLight: "#2E6B4F",
    secondary: "#C45C26",
    accent: "#D4A017",
    background: "#F3EDE3",
    surface: "#FFFBF5",
    surfaceAlt: "#EBE3D4",
    ink: "#1A1714",
    muted: "#5C534A",
    disabled: "#9A9188",
    onPrimary: "#FFF8EE",
    onSecondary: "#FFF8EE",
    success: "#2B6B3F",
    danger: "#B42318",
    warning: "#B45309",
    buttonPrimary: "#1F4D3A",
    buttonPrimaryText: "#FFF8EE",
    buttonSecondary: "#C45C26",
    buttonSecondaryText: "#FFF8EE",
    buttonDisabled: "#D7CFC3",
    line: "#D8CFC0",
    overlay: "#1A1714CC",
  },
};

const PAPER: AppThemeDef = {
  id: "paper",
  name: { hi: "कागज़ नीला", mr: "कागद निळा", en: "Paper navy" },
  plate: ["#F9F7F7", "#DBE2EF", "#3F72AF", "#112D4E"],
  scheme: "light",
  colors: {
    primary: "#112D4E",
    primaryDark: "#0B1D33",
    primaryLight: "#3F72AF",
    secondary: "#3F72AF",
    accent: "#3F72AF",
    background: "#F9F7F7",
    surface: "#FFFFFF",
    surfaceAlt: "#DBE2EF",
    ink: "#112D4E",
    muted: "#4A6080",
    disabled: "#8A99B0",
    onPrimary: "#F9F7F7",
    onSecondary: "#F9F7F7",
    success: "#2B6B3F",
    danger: "#B42318",
    warning: "#B45309",
    buttonPrimary: "#112D4E",
    buttonPrimaryText: "#F9F7F7",
    buttonSecondary: "#3F72AF",
    buttonSecondaryText: "#F9F7F7",
    buttonDisabled: "#DBE2EF",
    line: "#C9D3E3",
    overlay: "#112D4ECC",
  },
};

const NIGHT: AppThemeDef = {
  id: "night",
  name: { hi: "गहरी रात", mr: "गहिर्या रात्री", en: "Night sea" },
  plate: ["#0A2647", "#144272", "#205295", "#2C74B3"],
  scheme: "dark",
  colors: {
    primary: "#144272",
    primaryDark: "#061628",
    primaryLight: "#205295",
    secondary: "#2C74B3",
    accent: "#2C74B3",
    background: "#0A2647",
    surface: "#144272",
    surfaceAlt: "#205295",
    ink: "#E8F1FA",
    muted: "#A8C4DC",
    disabled: "#6B8AAA",
    onPrimary: "#E8F1FA",
    onSecondary: "#F4F8FC",
    success: "#5BD38A",
    danger: "#FF7A70",
    warning: "#F4C95D",
    buttonPrimary: "#2C74B3",
    buttonPrimaryText: "#F4F8FC",
    buttonSecondary: "#205295",
    buttonSecondaryText: "#F4F8FC",
    buttonDisabled: "#1A3A5C",
    line: "#205295",
    overlay: "#061628CC",
  },
};

const JAMUN: AppThemeDef = {
  id: "jamun",
  name: { hi: "जामुन", mr: "जांभळा", en: "Jamun" },
  plate: ["#000000", "#52057B", "#892CDC", "#BC6FF1"],
  scheme: "dark",
  colors: {
    primary: "#52057B",
    primaryDark: "#000000",
    primaryLight: "#892CDC",
    secondary: "#BC6FF1",
    accent: "#BC6FF1",
    background: "#000000",
    surface: "#1A0528",
    surfaceAlt: "#52057B",
    ink: "#F6E9FF",
    muted: "#C9A3E0",
    disabled: "#7A5A90",
    onPrimary: "#F6E9FF",
    onSecondary: "#1A0528",
    success: "#5BD38A",
    danger: "#FF7A70",
    warning: "#F4C95D",
    buttonPrimary: "#892CDC",
    buttonPrimaryText: "#F6E9FF",
    buttonSecondary: "#BC6FF1",
    buttonSecondaryText: "#1A0528",
    buttonDisabled: "#3A1A4A",
    line: "#52057B",
    overlay: "#000000CC",
  },
};

const PUDINA: AppThemeDef = {
  id: "pudina",
  name: { hi: "पुदीना", mr: "पुदीना", en: "Mint" },
  plate: ["#1FAB89", "#62D2A2", "#9DF3C4", "#D7FBE8"],
  scheme: "light",
  colors: {
    primary: "#1FAB89",
    primaryDark: "#147A62",
    primaryLight: "#62D2A2",
    secondary: "#147A62",
    accent: "#62D2A2",
    background: "#D7FBE8",
    surface: "#F4FFFB",
    surfaceAlt: "#9DF3C4",
    ink: "#0B3D32",
    muted: "#3D6B5E",
    disabled: "#7AA898",
    onPrimary: "#D7FBE8",
    onSecondary: "#D7FBE8",
    success: "#147A62",
    danger: "#B42318",
    warning: "#B45309",
    buttonPrimary: "#1FAB89",
    buttonPrimaryText: "#F4FFFB",
    buttonSecondary: "#147A62",
    buttonSecondaryText: "#F4FFFB",
    buttonDisabled: "#9DF3C4",
    line: "#7FE0B4",
    overlay: "#0B3D32CC",
  },
};

const CHAI: AppThemeDef = {
  id: "chai",
  name: { hi: "दूध-चाय", mr: "दूध-चहा", en: "Milk tea" },
  plate: ["#FDFFBC", "#FFEEBB", "#FFDCB8", "#FFC1B6"],
  scheme: "light",
  colors: {
    primary: "#8B4539",
    primaryDark: "#6E342C",
    primaryLight: "#C46B5C",
    secondary: "#C46B5C",
    accent: "#FFC1B6",
    background: "#FDFFBC",
    surface: "#FFEEBB",
    surfaceAlt: "#FFDCB8",
    ink: "#4A3028",
    muted: "#7A5A4E",
    disabled: "#B09A88",
    onPrimary: "#FDFFBC",
    onSecondary: "#FDFFBC",
    success: "#2B6B3F",
    danger: "#B42318",
    warning: "#B45309",
    buttonPrimary: "#8B4539",
    buttonPrimaryText: "#FDFFBC",
    buttonSecondary: "#C46B5C",
    buttonSecondaryText: "#FDFFBC",
    buttonDisabled: "#FFDCB8",
    line: "#E8C9A8",
    overlay: "#4A3028CC",
  },
};

const GULAB: AppThemeDef = {
  id: "gulab",
  name: { hi: "गुलाब", mr: "गुलाब", en: "Rose" },
  plate: ["#756AB6", "#AC87C5", "#E0AED0", "#FFE5E5"],
  scheme: "light",
  colors: {
    primary: "#756AB6",
    primaryDark: "#5A4F94",
    primaryLight: "#AC87C5",
    secondary: "#5E5299",
    accent: "#E0AED0",
    background: "#FFE5E5",
    surface: "#FFF6F6",
    surfaceAlt: "#E0AED0",
    ink: "#2F2750",
    muted: "#6B5F88",
    disabled: "#A898B8",
    onPrimary: "#FFE5E5",
    onSecondary: "#FFE5E5",
    success: "#2B6B3F",
    danger: "#B42318",
    warning: "#B45309",
    buttonPrimary: "#756AB6",
    buttonPrimaryText: "#FFE5E5",
    buttonSecondary: "#5E5299",
    buttonSecondaryText: "#FFE5E5",
    buttonDisabled: "#E0AED0",
    line: "#E0AED0",
    overlay: "#2F2750CC",
  },
};

export const THEMES: AppThemeDef[] = [FIELD, PAPER, NIGHT, JAMUN, PUDINA, CHAI, GULAB];
export const DEFAULT_THEME_ID: ThemeId = "field";

export function getTheme(id: ThemeId | string | undefined): AppThemeDef {
  return THEMES.find((t) => t.id === id) ?? FIELD;
}

export function cssVarsFromColors(c: AppColorSet): Record<string, string> {
  return {
    "--color-primary": c.primary,
    "--color-primary-dark": c.primaryDark,
    "--color-primary-light": c.primaryLight,
    "--color-secondary": c.secondary,
    "--color-accent": c.accent,
    "--color-background": c.background,
    "--color-surface": c.surface,
    "--color-surface-alt": c.surfaceAlt,
    "--color-ink": c.ink,
    "--color-muted": c.muted,
    "--color-disabled": c.disabled,
    "--color-on-primary": c.onPrimary,
    "--color-on-secondary": c.onSecondary,
    "--color-success": c.success,
    "--color-danger": c.danger,
    "--color-warning": c.warning,
    "--color-btn-primary": c.buttonPrimary,
    "--color-btn-primary-fg": c.buttonPrimaryText,
    "--color-btn-secondary": c.buttonSecondary,
    "--color-btn-secondary-fg": c.buttonSecondaryText,
    "--color-btn-disabled": c.buttonDisabled,
    "--color-line": c.line,
  };
}

export function themeCssText(theme: AppThemeDef = FIELD): string {
  const body = Object.entries(cssVarsFromColors(theme.colors))
    .map(([k, v]) => `${k}: ${v};`)
    .join(" ");
  return `:root { color-scheme: ${theme.scheme}; ${body} }`;
}
