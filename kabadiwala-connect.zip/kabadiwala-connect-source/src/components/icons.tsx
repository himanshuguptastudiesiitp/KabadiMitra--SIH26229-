import {
  BatteryCharging,
  Box,
  Cable,
  CircuitBoard,
  Cog,
  Monitor,
  Tv,
  type LucideIcon,
} from "lucide-react";
import type { MaterialId } from "@/lib/types";

export const MATERIAL_ICON: Record<MaterialId, LucideIcon> = {
  crt: Tv,
  lcd: Monitor,
  pcb: CircuitBoard,
  cables: Cable,
  batteries: BatteryCharging,
  motors: Cog,
  plastics: Box,
};
