import type { ReactNode } from "react";
import { ThemeInjector } from "@/theme/theme-injector";
import { AppShell } from "@/components/app-shell";

export function PhoneSkeleton() {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-background text-muted">
      …
    </div>
  );
}

export function PhoneChrome({
  children,
  shell = false,
}: {
  children: ReactNode;
  shell?: boolean;
}) {
  return (
    <div className="min-h-[100dvh] bg-background text-ink">
      <ThemeInjector />
      <div className="mx-auto flex min-h-[100dvh] w-full max-w-[430px] flex-col bg-background">
        <div className="flex-1 overflow-y-auto px-4 pb-24 pt-4">{children}</div>
        {shell ? <AppShell /> : null}
      </div>
    </div>
  );
}
