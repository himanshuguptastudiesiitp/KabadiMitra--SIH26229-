import { Link } from "@tanstack/react-router";
import { inr } from "@/lib/format";
import { materialLabel, t } from "@/lib/i18n";
import { lotAmount, statusToStep } from "@/lib/pipeline";
import { useAppStore } from "@/lib/store";
import type { Lot } from "@/lib/types";
import { MATERIAL_ICON } from "@/components/icons";

export function LotCard({ lot }: { lot: Lot }) {
  const language = useAppStore((s) => s.language);
  const Icon = MATERIAL_ICON[lot.category];
  const step = statusToStep(lot.status);
  return (
    <Link to="/trace" search={{ lot: lot.id }} className="block">
      <div className="flex items-center gap-3 rounded-xl bg-surface p-3 shadow-sm">
        <div className="flex size-12 items-center justify-center rounded-lg bg-surface-alt text-primary">
          <Icon className="size-6" />
        </div>
        <div className="min-w-0 flex-1">
          <p className="font-extrabold text-ink">{materialLabel(language, lot.category)}</p>
          <p className="text-sm text-muted">
            {lot.weightKg} kg · {t(language, step === "collect" ? "stepCollect" : step === "identify" ? "stepIdentify" : step === "value" ? "stepValue" : step === "match" ? "stepMatch" : step === "handover" ? "stepHandover" : step === "verify" ? "stepVerify" : step === "paid" ? "stepPaid" : "stepTrace")}
          </p>
        </div>
        <p className="text-lg font-extrabold tabular-nums text-ink">{inr(lotAmount(lot))}</p>
      </div>
    </Link>
  );
}
