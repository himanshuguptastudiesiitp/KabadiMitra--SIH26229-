import type { ButtonHTMLAttributes, InputHTMLAttributes, ReactNode } from "react";

export function Card({
  className = "",
  children,
}: {
  className?: string;
  children: ReactNode;
}) {
  return <div className={`rounded-xl bg-surface p-4 shadow-sm ${className}`}>{children}</div>;
}

export function ScreenTitle({ title, sub }: { title: string; sub?: string }) {
  return (
    <div>
      <h1 className="text-3xl font-extrabold leading-tight text-ink">{title}</h1>
      {sub ? <p className="mt-1 text-base text-muted">{sub}</p> : null}
    </div>
  );
}

export function BigButton({
  tone = "primary",
  className = "",
  children,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & {
  tone?: "primary" | "secondary" | "ghost";
}) {
  const look =
    tone === "secondary"
      ? "bg-btn-secondary text-btn-secondary-fg"
      : tone === "ghost"
        ? "bg-surface text-ink"
        : "bg-btn-primary text-btn-primary-fg";
  return (
    <button
      type="button"
      className={`flex min-h-14 w-full items-center justify-center rounded-xl text-lg font-extrabold disabled:bg-btn-disabled disabled:text-disabled ${look} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
}

export function TextField({
  label,
  className = "",
  ...props
}: InputHTMLAttributes<HTMLInputElement> & { label: string }) {
  return (
    <label className="flex flex-col gap-1">
      <span className="text-sm font-bold text-muted">{label}</span>
      <input
        className={`min-h-14 rounded-xl border border-line bg-surface px-3 text-lg font-bold text-ink ${className}`}
        {...props}
      />
    </label>
  );
}
