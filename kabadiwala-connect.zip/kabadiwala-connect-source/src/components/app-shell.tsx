import { Link, useRouterState } from "@tanstack/react-router";
import { Camera, House, ShieldAlert, Store, UserRound, Wallet, Settings } from "lucide-react";
import { t } from "@/lib/i18n";
import { useAppStore } from "@/lib/store";

export function AppShell() {
  const language = useAppStore((s) => s.language);
  const role = useAppStore((s) => s.role);
  const path = useRouterState({ select: (s) => s.location.pathname });

  const items =
    role === "recycler"
      ? [
          { to: "/recycler" as const, icon: Store, label: t(language, "recyclerDesk") },
          { to: "/prices" as const, icon: Wallet, label: t(language, "priceBoard") },
          { to: "/settings" as const, icon: Settings, label: t(language, "settings") },
        ]
      : role === "admin"
        ? [
            { to: "/admin" as const, icon: House, label: t(language, "adminDesk") },
            { to: "/trace" as const, icon: ShieldAlert, label: t(language, "traceLot") },
            { to: "/settings" as const, icon: Settings, label: t(language, "settings") },
          ]
        : [
            { to: "/" as const, icon: House, label: t(language, "appName") },
            { to: "/camera" as const, icon: Camera, label: t(language, "openCamera") },
            { to: "/earnings" as const, icon: Wallet, label: t(language, "earnings") },
            { to: "/user" as const, icon: UserRound, label: t(language, "userPage") },
            { to: "/settings" as const, icon: Settings, label: t(language, "settings") },
          ];

  return (
    <nav className="fixed bottom-0 left-1/2 z-20 w-full max-w-[430px] -translate-x-1/2 border-t border-line bg-surface">
      <ul className="grid grid-cols-5">
        {items.map((item) => {
          const Icon = item.icon;
          const on = path === item.to;
          return (
            <li key={item.to} className={items.length < 5 ? "col-span-1" : ""}>
              <Link
                to={item.to}
                className={`flex min-h-14 flex-col items-center justify-center gap-0.5 text-[10px] font-extrabold ${
                  on ? "text-primary" : "text-muted"
                }`}
              >
                <Icon className="size-5" />
                <span className="truncate px-1">{item.label}</span>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
