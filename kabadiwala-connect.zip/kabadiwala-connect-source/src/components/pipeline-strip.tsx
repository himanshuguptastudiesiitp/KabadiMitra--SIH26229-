import { t } from "@/lib/i18n";
import { PIPELINE_STEPS, statusToStep, stepIndex } from "@/lib/pipeline";
import { useAppStore } from "@/lib/store";
import type { LotStatus, PipelineStep } from "@/lib/types";

export function PipelineStrip({ current }: { current: LotStatus | PipelineStep }) {
  const language = useAppStore((s) => s.language);
  const step: PipelineStep =
    current === "collect" ||
    current === "identify" ||
    current === "value" ||
    current === "match" ||
    current === "handover" ||
    current === "verify" ||
    current === "paid" ||
    current === "trace"
      ? current
      : statusToStep(current);
  const idx = PIPELINE_STEPS.findIndex((s) => s.id === step);

  return (
    <div className="overflow-x-auto">
      <ol className="flex min-w-max gap-1">
        {PIPELINE_STEPS.map((s, i) => {
          const on = i === idx;
          const done = i < idx;
          return (
            <li
              key={s.id}
              className={`rounded-lg px-2 py-1 text-[11px] font-extrabold ${
                on ? "bg-primary text-on-primary" : done ? "bg-success text-on-primary" : "bg-surface-alt text-muted"
              }`}
            >
              {i + 1}. {t(language, s.key)}
            </li>
          );
        })}
      </ol>
    </div>
  );
}

export function PipelineIndex({ status }: { status: LotStatus }) {
  return stepIndex(status);
}
