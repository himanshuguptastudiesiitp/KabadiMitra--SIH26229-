import { Link } from "@tanstack/react-router";
import { t, type I18nKey } from "@/lib/i18n";
import { nextPath } from "@/lib/pipeline";
import { useAppStore } from "@/lib/store";
import type { Lot } from "@/lib/types";

function labelFor(lot: Lot | undefined): I18nKey {
  if (!lot) return "openCamera";
  switch (lot.status) {
    case "collected":
    case "identified":
      return "addScrap";
    case "valued":
    case "matched":
    case "offered":
      return "findRecycler";
    case "accepted":
      return "makeReceipt";
    case "handed":
      return "waitYard";
    case "verified":
      return "earnings";
    case "paid":
      return "traceLot";
    default:
      return "openCamera";
  }
}

export function NextStepCard({ lot }: { lot?: Lot }) {
  const language = useAppStore((s) => s.language);
  const to = nextPath(lot);
  return (
    <Link
      to={to as "/camera"}
      className="block rounded-xl bg-secondary p-4 text-on-secondary shadow-sm"
    >
      <p className="text-sm font-bold opacity-90">{lot ? lot.id : t(language, "noLots")}</p>
      <p className="mt-1 text-xl font-extrabold">{t(language, labelFor(lot))}</p>
    </Link>
  );
}
