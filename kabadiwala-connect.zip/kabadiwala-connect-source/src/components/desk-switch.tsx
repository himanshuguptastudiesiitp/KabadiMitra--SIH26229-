import { useNavigate } from "@tanstack/react-router";
import { t } from "@/lib/i18n";
import { homePath } from "@/lib/pipeline";
import { useAppStore } from "@/lib/store";
import type { UserRole } from "@/lib/types";

const ROLES: UserRole[] = ["collector", "recycler", "admin"];

export function DeskSwitch() {
  const language = useAppStore((s) => s.language);
  const role = useAppStore((s) => s.role);
  const setRole = useAppStore((s) => s.setRole);
  const navigate = useNavigate();

  function pick(next: UserRole) {
    setRole(next);
    void navigate({ to: homePath(next) });
  }

  return (
    <div className="grid grid-cols-3 gap-2">
      {ROLES.map((r) => (
        <button
          key={r}
          type="button"
          onClick={() => pick(r)}
          className={`min-h-11 rounded-xl text-xs font-extrabold ${
            role === r ? "bg-primary text-on-primary" : "bg-surface text-ink"
          }`}
        >
          {r === "collector" ? t(language, "roleCollector") : r === "recycler" ? t(language, "roleRecycler") : t(language, "roleAdmin")}
        </button>
      ))}
    </div>
  );
}
