import { createFileRoute } from "@tanstack/react-router";
import { PhoneChrome } from "@/components/phone-chrome";
import { ThemeScreen } from "@/screens/theme-screen";

export const Route = createFileRoute("/theme")({ component: Page });

function Page() {
  return (
    <PhoneChrome shell>
      <ThemeScreen />
    </PhoneChrome>
  );
}
