import { createFileRoute } from "@tanstack/react-router";
import { PhoneChrome } from "@/components/phone-chrome";
import { UserScreen } from "@/screens/user-screen";

export const Route = createFileRoute("/user")({ component: Page });

function Page() {
  return (
    <PhoneChrome shell>
      <UserScreen />
    </PhoneChrome>
  );
}
