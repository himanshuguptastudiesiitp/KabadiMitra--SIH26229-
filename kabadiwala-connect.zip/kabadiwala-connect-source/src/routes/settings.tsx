import { createFileRoute } from "@tanstack/react-router";
import { PhoneChrome } from "@/components/phone-chrome";
import { SettingsScreen } from "@/screens/settings-screen";

export const Route = createFileRoute("/settings")({ component: Page });

function Page() {
  return (
    <PhoneChrome shell>
      <SettingsScreen />
    </PhoneChrome>
  );
}
