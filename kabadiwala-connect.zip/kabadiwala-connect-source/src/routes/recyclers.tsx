import { createFileRoute } from "@tanstack/react-router";
import { PhoneChrome } from "@/components/phone-chrome";
import { RecyclersScreen } from "@/screens/recyclers-screen";

export const Route = createFileRoute("/recyclers")({ component: Page });

function Page() {
  return (
    <PhoneChrome shell>
      <RecyclersScreen />
    </PhoneChrome>
  );
}
