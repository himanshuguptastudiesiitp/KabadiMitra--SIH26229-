import { createFileRoute } from "@tanstack/react-router";
import { PhoneChrome } from "@/components/phone-chrome";
import { SafetyScreen } from "@/screens/safety-screen";

export const Route = createFileRoute("/safety")({ component: Page });

function Page() {
  return (
    <PhoneChrome shell>
      <SafetyScreen />
    </PhoneChrome>
  );
}
