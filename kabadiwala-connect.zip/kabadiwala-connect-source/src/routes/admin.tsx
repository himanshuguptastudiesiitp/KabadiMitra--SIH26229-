import { createFileRoute } from "@tanstack/react-router";
import { PhoneChrome } from "@/components/phone-chrome";
import { AdminScreen } from "@/screens/admin-screen";

export const Route = createFileRoute("/admin")({ component: Page });

function Page() {
  return (
    <PhoneChrome shell>
      <AdminScreen />
    </PhoneChrome>
  );
}
