import { createFileRoute } from "@tanstack/react-router";
import { PhoneChrome } from "@/components/phone-chrome";
import { HandoverScreen } from "@/screens/handover-screen";

export const Route = createFileRoute("/handover")({ component: Page });

function Page() {
  return (
    <PhoneChrome shell>
      <HandoverScreen />
    </PhoneChrome>
  );
}
