import { createFileRoute } from "@tanstack/react-router";
import { PhoneChrome } from "@/components/phone-chrome";
import { PricesScreen } from "@/screens/prices-screen";

export const Route = createFileRoute("/prices")({ component: Page });

function Page() {
  return (
    <PhoneChrome shell>
      <PricesScreen />
    </PhoneChrome>
  );
}
