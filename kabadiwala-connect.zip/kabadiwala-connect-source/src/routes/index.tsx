import { createFileRoute } from "@tanstack/react-router";
import { PhoneChrome } from "@/components/phone-chrome";
import { HomeScreen } from "@/screens/home-screen";

export const Route = createFileRoute("/")({ component: Page });

function Page() {
  return (
    <PhoneChrome shell>
      <HomeScreen />
    </PhoneChrome>
  );
}
