import { createFileRoute } from "@tanstack/react-router";
import { DownloadScreen } from "@/screens/download-screen";

export const Route = createFileRoute("/download")({ component: DownloadScreen });
