import { createFileRoute } from "@tanstack/react-router";
import { PhoneChrome } from "@/components/phone-chrome";
import { RecyclerScreen } from "@/screens/recycler-screen";

export const Route = createFileRoute("/recycler")({ component: Page });

function Page() {
  return (
    <PhoneChrome shell>
      <RecyclerScreen />
    </PhoneChrome>
  );
}
