import { createFileRoute } from "@tanstack/react-router";
import { RegisterScreen } from "@/screens/register-screen";

export const Route = createFileRoute("/register")({ component: RegisterScreen });
