import { createFileRoute } from "@tanstack/react-router";
import { PhoneChrome } from "@/components/phone-chrome";
import { EarningsScreen } from "@/screens/earnings-screen";

export const Route = createFileRoute("/earnings")({ component: Page });

function Page() {
  return (
    <PhoneChrome shell>
      <EarningsScreen />
    </PhoneChrome>
  );
}
