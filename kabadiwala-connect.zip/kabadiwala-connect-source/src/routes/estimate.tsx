import { createFileRoute } from "@tanstack/react-router";
import { PhoneChrome } from "@/components/phone-chrome";
import { EstimateScreen } from "@/screens/estimate-screen";

export const Route = createFileRoute("/estimate")({ component: Page });

function Page() {
  return (
    <PhoneChrome shell>
      <EstimateScreen />
    </PhoneChrome>
  );
}
