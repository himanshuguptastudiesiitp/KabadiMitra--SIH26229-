import { createFileRoute } from "@tanstack/react-router";
import { PhoneChrome } from "@/components/phone-chrome";
import { TraceScreen } from "@/screens/trace-screen";

export const Route = createFileRoute("/trace")({ component: Page });

function Page() {
  return (
    <PhoneChrome shell>
      <TraceScreen />
    </PhoneChrome>
  );
}
