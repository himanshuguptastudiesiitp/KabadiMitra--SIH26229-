import { createFileRoute } from "@tanstack/react-router";
import { PhoneChrome } from "@/components/phone-chrome";
import { AddScreen } from "@/screens/add-screen";

export const Route = createFileRoute("/add")({ component: Page });

function Page() {
  return (
    <PhoneChrome shell>
      <AddScreen />
    </PhoneChrome>
  );
}
