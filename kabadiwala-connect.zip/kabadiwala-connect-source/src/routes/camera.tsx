import { createFileRoute } from "@tanstack/react-router";
import { PhoneChrome } from "@/components/phone-chrome";
import { CameraScreen } from "@/screens/camera-screen";

export const Route = createFileRoute("/camera")({ component: Page });

function Page() {
  return (
    <PhoneChrome shell>
      <CameraScreen />
    </PhoneChrome>
  );
}
